SET 'pipeline.name' = 'order_fulfillment_template';
set 'state.checkpoints.dir' = 'file:///data/flink/checkpoints/order_fulfillment_template';
set 'execution.checkpointing.interval' = '60000';

create database `default_catalog`.`exchange`;
CREATE TABLE IF NOT EXISTS `default_catalog`.`exchange`.`order_fulfillment_src` (
    `nid` BIGINT NOT NULL,
    `id` BIGINT NOT NULL,
    `order_id` BIGINT NOT NULL,
    `pair_code` STRING NOT NULL,
    `user_id` BIGINT NOT NULL,
    `broker_id` INT NOT NULL,
    `clazz` INT NOT NULL,
    `side` STRING NOT NULL,
    `entrust_price` STRING NOT NULL,
    `amount` STRING NOT NULL,
    `deal_amount` STRING NOT NULL,
    `quote_amount` STRING NOT NULL,
    `deal_quote_amount` STRING NOT NULL,
    `cancel_amount` STRING NOT NULL,
    `stp_amount` STRING NOT NULL,
    `source_info` STRING NOT NULL,
    `system_order_type` INT NOT NULL,
    `relation_order_id` STRING NOT NULL,
    `sub_status` INT NOT NULL,
    `status` INT NOT NULL,
    `system_type` INT NOT NULL,
    `stp` INT NOT NULL,
    `create_on` TIMESTAMP(3),
    `update_on` TIMESTAMP(3),
    PRIMARY KEY(`nid`)
    NOT ENFORCED
) with (
    'hostname' = '192.168.10.200',
    'port' = '3306',
    'username' = 'root',
    'password' = 'qhxc@021',
    'database-name' = 'test',
    'table-name' = 'order_fulfillment_template',
    'connector' = 'mysql-cdc',
    'server-time-zone' = 'Asia/Shanghai'
);
CREATE TABLE IF NOT EXISTS `default_catalog`.`exchange`.`order_fulfillment_sink` (
    `nid` BIGINT NOT NULL,
    `id` BIGINT NOT NULL,
    `order_id` BIGINT NOT NULL,
    `pair_code` STRING NOT NULL,
    `user_id` BIGINT NOT NULL,
    `broker_id` INT NOT NULL,
    `clazz` INT NOT NULL,
    `side` STRING NOT NULL,
    `entrust_price` STRING,
    `amount` STRING,
    `deal_amount` STRING,
    `quote_amount` STRING,
    `deal_quote_amount` STRING,
    `cancel_amount` STRING,
    `stp_amount` STRING,
    `source_info` STRING NOT NULL,
    `system_order_type` INT NOT NULL,
    `relation_order_id` STRING NOT NULL,
    `sub_status` INT NOT NULL,
    `status` INT NOT NULL,
    `system_type` INT NOT NULL,
    `stp` INT NOT NULL,
    `create_on` TIMESTAMP(3) ,
    `update_on` TIMESTAMP(3) ,
    PRIMARY KEY(`nid`)
    NOT ENFORCED
) WITH (
    'connector' = 'elasticsearch-7',
    'hosts' = 'http://192.168.13.108:9200',
    'username' = 'elastic',
    'password' = '2STTKpSTtSeR',
    'index' = 'order_fulfillment2'
);
insert into `default_catalog`.`exchange`.`order_fulfillment_sink` (nid,id, order_id, pair_code, user_id,broker_id,clazz,side,entrust_price,amount,deal_amount,quote_amount,deal_quote_amount,cancel_amount,stp_amount,source_info,system_order_type,relation_order_id,sub_status,status,system_type,stp, create_on, update_on) select nid,id, order_id, pair_code, user_id,broker_id,clazz,side,entrust_price,amount,deal_amount,quote_amount,deal_quote_amount,cancel_amount,stp_amount,source_info,system_order_type,relation_order_id,sub_status,status,system_type,stp, create_on, update_on from `default_catalog`.`exchange`.`order_fulfillment_src`;

