#!/bin/bash
#Description: 按照规则对表数据归档
#Author:WangJie
#Date:2022-09-13

source /etc/profile
time=`date +%s`
today=$(((${time}+3600*8)/86400*86400-3600*8))'000'
yesterday=$(((${time}+3600*8)/86400*86400-3600*32))'000'
last_15_days=$(((${time}+3600*8)/86400*86400-3600*320))'000'
last_16_days=$(((${time}+3600*8)/86400*86400-3600*330))'000'
last_one_day=`date -d yesterday +'%Y-%m-%d 00:00:00'`
last_two_days=`date -d '-2 days' +'%Y-%m-%d 00:00:00'`
last15day=`date -d '-15 days' +'%Y-%m-%d 00:00:00'`
last16day=`date -d '-16 days' +'%Y-%m-%d 00:00:00'`


year=`date +'%Y'`
month=`date +'%m'|sed 's/0//g' `
user=root
password='qhxc@021'
dbname=test
host=192.168.10.200
port=3306

es_user=elastic
es_passwd=2STTKpSTtSeR
es_host='192.168.13.108:9200'

s_order_fulfillment=order_fulfillment
t_order_fulfillment=order_fulfillment_${year}_${month}



#order_fulfillment表归档规则: 保留最近3天数据
check_table_cnt=`mysql -u$user -p$password -e "select count(1) from information_schema.tables where table_name='${s_order_fulfillment}' and table_schema='${dbname}' " | sed -n '2,1p'`
if [ $check_table_cnt -eq 1 ]
  then
    echo "开始归档${s_order_fulfillment} 表......."
    pt-archiver --source u=$user,p=$password,h=$host,P=$port,D=$dbname,t=$s_order_fulfillment --dest u=$user,p=$password,h=$host,P=$port,D=$dbname,t=$t_order_fulfillment --where="create_on < date_add(curdate(),interval -2 day)" --ignore --progress=1000 --limit=1000 --statistics --bulk-insert --bulk-delete --txn-size=1000 --no-check-charset
  else
    echo "${s_order_fulfillment} 表不存在!"
fi

#同步数据到es
sed "s/order_fulfillment_template/$t_order_fulfillment/g" order_fulfillment_template.sql > $t_order_fulfillment.sql 
/data/flink/bin/sql-client.sh -f $t_order_fulfillment.sql
#清理es中3个月之前的数据
curl -s -XPOST "http://$es_user:$es_passwd@$es_host/order_fulfillment/_delete_by_query" -H 'Content-Type: application/json' -d'
{
  "query": {
    "range": {
      "create_on": {
        "lt": "now-90d",
        "format": "epoch_millis"
      }
    }
  }
}'

#判断es中的数据是否同步完成
#cnt_es=`curl  "http://$es_user:$es_passwd@$es_host/order_fulfillment/_count" |awk -F: '{print $2}' |awk -F, '{print $1}'`
cnt_es=`curl -s -XPOST "http://$es_user:$es_passwd@$es_host/_sql?format=txt " -H 'Content-Type: application/json' -d'
{
  "query": " select  nid from  order_fulfillment2 order by nid desc limit 1  "
 }' | sed -n '3,1p' `

cnt_mysql=`mysql -u$user -p$password -h$host $dbname -e " select nid from order_fulfillment order by nid desc limit 1 " |sed -n '2,1p'`
if [[ $cnt_es -eq $cnt_mysql ]];then
  echo "同步完成"
#取消当前已完成的同步任务
  /data/flink/bin/flink cancel $(/data/flink/bin/flink list | grep $t_order_fulfillment |awk -F: '{print $4}')
fi





