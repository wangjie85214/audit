#!/bin/bash
#Description: 按照规则对表数据归档
#Author:WangJie
#Date:2022-08-31

source /etc/profile
time=`date +%s`
today=$(((${time}+3600*8)/86400*86400-3600*8))'000'
yesterday=$(((${time}+3600*8)/86400*86400-3600*32))'000'
last_15_days=$(((${time}+3600*8)/86400*86400-3600*320))'000'
last_16_days=$(((${time}+3600*8)/86400*86400-3600*330))'000'
last_one_day=`date -d yesterday +'%Y-%m-%d 00:00:00'`
last_two_days=`date -d '-2 days' +'%Y-%m-%d 00:00:00'`
last15day=`date -d '-15 days' +'%Y-%m-%d 00:00:00'`
last16day=`date -d '-16 days' +'%Y-%m-%d 00:00:00'`


year=`date +'%Y'`
month=`date +'%m'|sed 's/0//g' `
user=root
password='qhxc@021'
dbname=test
host=192.168.10.200
port=3306

es_user=elastic
es_passwd=2STTKpSTtSeR
es_host='192.168.13.108:9200'

s_order_fulfillment=order_fulfillment
t_order_fulfillment=order_fulfillment_${year}_${month}

s_orders=orders
t_orders=orders_${year}_${month}

s_bill=bill
t_bill=bill_${year}_${month}

s_t_order_sequence=t_order_sequence
t_t_order_sequence=t_order_sequence_${year}_${month}

s_t_exchange_match_result=t_exchange_match_result
t_t_exchange_match_result=t_exchange_match_result_${year}_${month}

s_t_order_sequence_placed_order=t_order_sequence_placed_order
t_t_order_sequence_placed_order=t_order_sequence_placed_order_${year}_${month}


#order_fulfillment表归档规则: 保留最近3天数据
check_table_cnt=`mysql -u$user -p$password -e "select count(1) from information_schema.tables where table_name='${s_order_fulfillment}' and table_schema='${dbname}' " | sed -n '2,1p'`
if [ $check_table_cnt -eq 1 ]
  then
    echo "开始归档${s_order_fulfillment} 表......."
    pt-archiver --source u=$user,p=$password,h=$host,P=$port,D=$dbname,t=$s_order_fulfillment --dest u=$user,p=$password,h=$host,P=$port,D=$dbname,t=$t_order_fulfillment --where="create_on >= date_add(curdate(),interval -4 day) and create_on < date_add(curdate(),interval -1 day)" --ignore --progress=1000 --limit=1000 --statistics --bulk-insert --bulk-delete --txn-size=1000 --no-check-charset
  else
    echo "${s_order_fulfillment} 表不存在!"
fi

#orders表归档规则: status=5, clazz=1 , 保留最近一天
check_table_cnt=`mysql -u$user -p$password -e "select count(1) from information_schema.tables where table_name='${s_orders}' and table_schema='${dbname}' " | sed -n '2,1p'`
if [ $check_table_cnt -eq 1 ]
  then
    echo "开始归档${s_orders} 表......."
    pt-archiver --source u=$user,p=$password,h=$host,P=$port,D=$dbname,t=$s_orders --dest u=$user,p=$password,h=$host,P=$port,D=$dbname,t=$t_orders --where="status=5 and clazz=1 and create_on >= date_add(curdate(),interval -2 day) and create_on < date_add(curdate(),interval -1 day)" --ignore --progress=1000 --limit=1000 --statistics --bulk-insert --bulk-delete --txn-size=1000 --no-check-charset
  else
    echo "${t_orders} 表不存在!"
fi

#bill表归档规则: 保留最近三天
check_table_cnt=`mysql -u$user -p$password -e "select count(1) from information_schema.tables where table_name='${s_bill}' and table_schema='${dbname}' " | sed -n '2,1p'`
if [ $check_table_cnt -eq 1 ]
  then
    echo "开始归档${s_bill} 表......."
    pt-archiver --source u=$user,p=$password,h=$host,P=$port,D=$dbname,t=$s_bill --dest u=$user,p=$password,h=$host,P=$port,D=$dbname,t=$t_bill --where="create_on >= date_add(curdate(),interval -4 day) and create_on < date_add(curdate(),interval -1 day)" --ignore --progress=1000 --limit=1000 --statistics --bulk-insert --bulk-delete --txn-size=1000 --no-check-charset
  else
    echo "${t_bill} 表不存在!"
fi

#同步数据到es
sed 's/bill_template/$t_bill/g' bill_template.sql > bill_bak.sql 
/data/flink/bin/sql-client -f bill_bak.sql
#清理es中3个月之前的数据
curl -XPOST "http://$es_user:$es_passwd@$es_host/bill/_delete_by_query" -H 'Content-Type: application/json' -d'
{
  "query": {
    "range": {
      "create_on": {
        "lt": "now-90d",
        "format": "epoch_millis"
      }
    }
  }
}'
#判断es中的数据是否同步完成
cnt_es=`curl  "http://$es_user:$es_passwd@$es_host/bill/_count" |awk -F: '{print $2}' |awk -F, '{print $1}'`
cnt_mysql=`mysql -u$user -p$password -h$host $dbname -e "select count(1) from bill" |sed -n '2,1p'`
if [[ $cnt_es == $cnt_mysql ]];then
  echo "同步完成"
#取消当前已完成的同步任务
  /data/flink/bin/flink cancel $(/data/flink/bin/flink list | grep $t_bill |awk -F: '{print $4}')
fi

#t_order_sequence表归档规则: 保留最近15天 
check_table_cnt=`mysql -u$user -p$password -e "select count(1) from information_schema.tables where table_name='${t_t_order_sequence}' and table_schema='${dbname}' " | sed -n '2,1p'`
if [ $check_table_cnt -eq 1 ]
  then
    echo "开始归档${s_t_order_sequence} 表......."
    pt-archiver --source u=$user,p=$password,h=$host,P=$port,D=$dbname,t=$s_t_order_sequence --dest u=$user,p=$password,h=$host,P=$port,D=$dbname,t=$t_t_order_sequence --where="ts >= unix_timestamp(concat(date_add(curdate(),interval -16 day),' 00:00:00'))*1000 and ts < unix_timestamp(concat(date_add(curdate(),interval -15 day),' 00:00:00'))*1000 " --ignore --progress=1000 --limit=1000 --statistics --bulk-insert --bulk-delete --txn-size=1000 --no-check-charset
  else
    echo "${t_t_order_sequence}表不存在！"
fi

#t_exchange_match_result表归档规则: 保留最近15天
check_table_cnt=`mysql -u$user -p$password -e "select count(1) from information_schema.tables where table_name='${s_t_exchange_match_result}' and table_schema='${dbname}' " | sed -n '2,1p'`
if [ $check_table_cnt -eq 1 ]
  then
    echo "开始归档${s_t_exchange_match_result} 表......."
    pt-archiver --source u=$user,p=$password,h=$host,P=$port,D=$dbname,t=$s_t_exchange_match_result --dest u=$user,p=$password,h=$host,P=$port,D=$dbname,t=$t_t_exchange_match_result --where="ts >= unix_timestamp(concat(date_add(curdate(),interval -16 day),' 00:00:00'))*1000 and ts < unix_timestamp(concat(date_add(curdate(),interval -15 day),' 00:00:00'))*1000 " --ignore --progress=1000 --limit=1000 --statistics --bulk-insert --bulk-delete --txn-size=1000 --no-check-charset
  else
    echo "${t_t_exchange_match_result} 表不存在!"
fi

#t_order_sequence_placed_order表归档规则: 保留最近15天
check_table_cnt=`mysql -u$user -p$password -e "select count(1) from information_schema.tables where table_name='${t_t_order_sequence_placed_order}' and table_schema='${dbname}' " | sed -n '2,1p'`
if [ $check_table_cnt -eq 1 ]
  then
    pt-archiver --source u=$user,p=$password,h=$host,P=$port,D=$dbname,t=$s_t_order_sequence_placed_order --dest u=$user,p=$password,h=$host,P=$port,D=$dbname,t=$t_t_order_sequence_placed_order --where="f_created_at >= date_add(curdate(),interval -16 day) and f_created_at < date_add(curdate(),interval -15 day) " --ignore --progress=1000 --limit=1000 --statistics --bulk-insert --bulk-delete --txn-size=1000 --no-check-charset
  else
    echo "${t_t_order_sequence_placed_order}表不存在！"
fi




