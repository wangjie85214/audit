#!/bin/bash
set -o pipefail
#Description: 每天进行全量备份mysql库
#Author:WangJie
#Date:2022-01-07
source /etc/profile
mkdir -p /data/mysqlbackup/logs
logpath=/data/mysqlbackup/logs/
ip=`/usr/sbin/ip addr|grep -A 2 'state UP'|tail -n 1|awk '{print $2}'|awk -F'/' '{print $1}'|tr '.' '-'`
baktime=`date +%Y-%m-%d`
begin=`date +"%Y年%m月%d日 %H:%M:%S"`
begin_time=`date +"%Y-%m-%d %H:%M:%S"`
user=bkpuser
passwd='cf22061efa0S5@!'
port=3306
mysql -u$user -p$passwd -P$port -e 'show databases;' > $logpath/errorlog-`date +%Y-%m-%d`.log 2>&1 | grep -Ev 'Database|information_schema|performance_schema|sys' | xargs mysqldump -u$user -p$passwd -P$port --databases --single-transaction --master-data=2 |gzip -c |ssh mysqlbak@192.168.10.15 "cat > /data/mysqlbackup/fullbackup/'$ip'-'$port'-'$baktime'.sql.gz"

errorlog_file=errorlog-`date +%Y-%m-%d`.log
error_msg=`grep -i 'ERROR' $logpath/$errorlog_file`

instance_name=`hostname`
backup_type=1
start_time=$begin_time
end_time=`date +"%Y-%m-%d %H:%M:%S"`
backup_filename=$ip-$port-$baktime.sql.gz
echo $backup_filename
backup_filesize=`ssh mysqlbak@192.168.10.15 du -bh /data/mysqlbackup/fullbackup/$backup_filename|awk '{print $1}'`
storage_type=0


if [ -z "$error_msg" ];then
  backup_status=1
  last=`date +"%Y年%m月%d日 %H:%M:%S"`
  echo "开始:$begin  结束:$last  $ip-$port successful" >>$logpath/backuplog-`date +%Y-%m-%d`.log
  mysql -uroot -pqhxc@021 -h192.168.13.25 archery -e "insert into backup_log(instance_name,backup_type,start_time,end_time,backup_filename,backup_filesize,storage_type,backup_status,message,create_time,update_time) values('$instance_name',$backup_type,'$start_time','$end_time','$backup_filename','$backup_filesize',$storage_type,$backup_status,'$error_msg',now(),now())"

else
  backup_status=0
  echo "$ip-$port fail" >>$logpath/backuplog-`date +%Y-%m-%d`.log
#备份失败发送告警通知
#  curl -H 'Servicetoken:7b96302ba3bc37975d8e821bc847ee98' -X POST -d '{"receiver":"13220187293", "type":"sms","title":"alarm_sms","content":"mysql数据库备份失败"}' 'http://www.linkedsee.com/alarm/cloudchannel'
  backup_status=0
  mysql -uroot -pqhxc@021 -h192.168.13.25 archery -e "insert into backup_log(instance_name,backup_type,start_time,end_time,backup_filename,backup_filesize,storage_type,backup_status,message,create_time,update_time) values('$instance_name',$backup_type,'$start_time','$end_time','$backup_filename','$backup_filesize',$storage_type,$backup_status,'$error_msg',now(),now())"

fi


