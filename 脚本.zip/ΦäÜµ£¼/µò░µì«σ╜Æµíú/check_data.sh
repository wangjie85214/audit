#!/bin/bash
#Description:检验es与mysql的数据一致性
#Author:WangJie
#Date:2022-10-11

set -e
source /etc/profile

before_10min=`date -d '-10 min' +'%Y-%m-%d %H:%M:%S'`
current_time=`date +'%Y-%m-%d %H:%M:%S'`

user=root
password='qhxc@021'
dbname=exchange
host=192.168.13.139
port=3306

es_user=elastic
es_passwd=2STTKpSTtSeR
es_host='192.168.13.108:9200'

t_match_orders=match_orders
t_order_fulfillment=order_fulfillment
t_bill=bill

#检查mysql表数据量
cnt_mysql_match_orders=`mysql -u$user -p$password -h$host $dbname -e " select count(1) from $t_match_orders " | sed -n '2,1p' `
cnt_es_match_orders=`curl -s -XPOST "http://$es_user:$es_passwd@$es_host/_sql?format=txt " -H 'Content-Type: application/json' -d'
{
  "query": "select count(1) from match_orders "
 }' | sed -n '3,1p' `

if [ $cnt_mysql_match_orders -eq $cnt_es_match_orders ]
  then
     echo "$current_time: MySQL数据库与ES数据库的表match_orders数据校验正常，记录数为:$cnt_mysql_match_orders"
  else
     echo "$current_time: MySQL数据库与ES数据库的表match_orders数据校验异常,MySQL数据库match_orders表数据量:$cnt_mysql_match_orders,ES数据库match_orders表数据量:$cnt_es_match_orders"
fi

cnt_mysql_order_fulfillment=`mysql -u$user -p$password -h$host $dbname -e " select count(1) from $t_order_fulfillment " | sed -n '2,1p' `
cnt_es_order_fulfillment=`curl -s -XPOST "http://$es_user:$es_passwd@$es_host/_sql?format=txt " -H 'Content-Type: application/json' -d'
{
  "query": "select count(1) from order_fulfillment "
 }' | sed -n '3,1p' `

if [ $cnt_mysql_order_fulfillment -eq $cnt_es_order_fulfillment ]
  then
     echo "$current_time: MySQL数据库与ES数据库的表order_fulfillment数据校验正常，记录数为:$cnt_mysql_order_fulfillment"
  else
     echo "$current_time: MySQL数据库与ES数据库的表order_fulfillment数据校验异常,MySQL数据库order_fulfillment数据量:$cnt_mysql_order_fulfillment,ES数据库order_fulfillment表数据量:$cnt_es_order_fulfillment"
fi

cnt_mysql_bill=`mysql -u$user -p$password -h$host $dbname -e " select count(1) from $t_bill where action=3 " | sed -n '2,1p' `
cnt_es_bill=`curl -s -XPOST "http://$es_user:$es_passwd@$es_host/_sql?format=txt " -H 'Content-Type: application/json' -d'
{
  "query": "select count(1) from bill "
 }' | sed -n '3,1p' `

if [ $cnt_mysql_bill -eq $cnt_es_bill ]
  then
     echo "$current_time: MySQL数据库与ES数据库的表bill数据校验正常，记录数为:$cnt_mysql_bill"
  else
     echo "$current_time: MySQL数据库与ES数据库的表bill数据校验异常,MySQL数据库bill数据量:$cnt_mysql_bill,ES数据库bill表数据量:$cnt_es_bill"
fi

