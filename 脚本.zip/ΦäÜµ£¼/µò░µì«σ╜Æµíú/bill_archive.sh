#!/bin/bash
#Description: 按照规则对表数据归档
#Author:WangJie
#Date:2022-09-13

source /etc/profile
time=`date +%s`
today=$(((${time}+3600*8)/86400*86400-3600*8))'000'
yesterday=$(((${time}+3600*8)/86400*86400-3600*32))'000'
last_15_days=$(((${time}+3600*8)/86400*86400-3600*320))'000'
last_16_days=$(((${time}+3600*8)/86400*86400-3600*330))'000'
last_one_day=`date -d yesterday +'%Y-%m-%d 00:00:00'`
last_two_days=`date -d '-2 days' +'%Y-%m-%d 00:00:00'`
last15day=`date -d '-15 days' +'%Y-%m-%d 00:00:00'`
last16day=`date -d '-16 days' +'%Y-%m-%d 00:00:00'`


year=`date +'%Y'`
month=`date +'%m'|sed 's/0//g' `
user=root
password='qhxc@021'
dbname=test
host=192.168.10.200
port=3306

es_user=elastic
es_passwd=2STTKpSTtSeR
es_host='192.168.13.108:9200'

s_bill=bill
t_bill=bill_${year}_${month}


#bill表归档规则: 保留最近30天数据
check_table_cnt=`mysql -u$user -p$password -e "select count(1) from information_schema.tables where table_name='${t_bill}' and table_schema='${dbname}' " | sed -n '2,1p'`
if [ $check_table_cnt -eq 1 ]
  then
    echo "开始归档${s_bill} 表......."
    pt-archiver --source u=$user,p=$password,h=$host,P=$port,D=$dbname,t=$s_bill --dest u=$user,p=$password,h=$host,P=$port,D=$dbname,t=$t_bill --where="create_on < date_add(curdate(),interval -2 day)" --ignore --progress=1000 --limit=1000 --statistics --bulk-insert --bulk-delete --txn-size=1000 --no-check-charset --nosafe-auto-increment
  else
    echo "${t_bill} 表不存在!请先创建表"
    exit 1
fi

#同步数据到es
sed "s/bill_template/$t_bill/g" bill_template.sql > $t_bill.sql 
/data/flink/bin/sql-client.sh -f $t_bill.sql
#清理es中3个月之前的数据
curl -s -XPOST "http://$es_user:$es_passwd@$es_host/bill/_delete_by_query" -H 'Content-Type: application/json' -d'
{
  "query": {
    "range": {
      "create_on": {
        "lt": "now-90d",
        "format": "epoch_millis"
      }
    }
  }
}'

#判断es中的数据是否同步完成
cnt_es=`curl -s -XPOST "http://$es_user:$es_passwd@$es_host/_sql?format=txt " -H 'Content-Type: application/json' -d'
{
  "query": "select  id  from bill where create_on < (current_date + INTERVAL -2 day)  order by id desc limit 1  "
 }' |sed -n '3,1p'`

echo "当前ES中bill最大ID为$cnt_es"

cnt_mysql=`mysql -u$user -p$password -h$host $dbname -e " select id from $t_bill order by id desc limit 1 " |sed -n '2,1p'`
echo "当前MySQL中bill最大ID为$cnt_mysql"


while [[ $cnt_mysql -gt $cnt_es ]]
do
  cnt_es=`curl -s -XPOST "http://$es_user:$es_passwd@$es_host/_sql?format=txt " -H 'Content-Type: application/json' -d'
	{
	  "query": " select  id from  bill where create_on < (current_date + INTERVAL -2 day) order by id desc limit 1  "
	 }' | sed -n '3,1p' `
  sleep 10
  echo "当前ES中bill最大ID为$cnt_es"
done
echo "$t_bill 任务同步完成！"
/data/flink/bin/flink cancel $(/data/flink/bin/flink list | grep $t_bill |awk -F: '{print $4}')
