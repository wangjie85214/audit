#!/bin/bash
#Description: 按照规则对表数据归档
#Author:WangJie
#Date:2022-08-31

source /etc/profile
time=`date +%s`
today=$(((${time}+3600*8)/86400*86400-3600*8))'000'
yesterday=$(((${time}+3600*8)/86400*86400-3600*32))'000'
last_15_days=$(((${time}+3600*8)/86400*86400-3600*320))'000'
last_16_days=$(((${time}+3600*8)/86400*86400-3600*330))'000'
last_one_day=`date -d yesterday +'%Y-%m-%d 00:00:00'`
last_two_days=`date -d '-2 days' +'%Y-%m-%d 00:00:00'`
last15day=`date -d '-15 days' +'%Y-%m-%d 00:00:00'`
last16day=`date -d '-16 days' +'%Y-%m-%d 00:00:00'`


year=`date +'%Y'`
month=`date +'%m'|sed 's/0//g' `
user=root
password='qhxc@021'
dbname=test
host=192.168.10.200
port=3306


s_t_exchange_match_result=t_exchange_match_result
t_t_exchange_match_result=t_exchange_match_result_${year}_${month}


#t_exchange_match_result表归档规则: 保留最近15天
check_table_cnt=`mysql -u$user -p$password -e "select count(1) from information_schema.tables where table_name='${s_t_exchange_match_result}' and table_schema='${dbname}' " | sed -n '2,1p'`
if [ $check_table_cnt -eq 1 ]
  then
    echo "开始归档${s_t_exchange_match_result} 表......."
    pt-archiver --source u=$user,p=$password,h=$host,P=$port,D=$dbname,t=$s_t_exchange_match_result --dest u=$user,p=$password,h=$host,P=$port,D=$dbname,t=$t_t_exchange_match_result --where="ts < unix_timestamp(concat(date_add(curdate(),interval -15 day),' 00:00:00'))*1000 " --ignore --progress=1000 --limit=1000 --statistics --bulk-insert --bulk-delete --txn-size=1000 --no-check-charset
  else
    echo "${t_t_exchange_match_result} 表不存在!"
fi
