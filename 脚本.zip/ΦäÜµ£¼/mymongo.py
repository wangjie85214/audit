#encoding=utf-8
import pymongo
import datetime
import requests
import json

#定义钉钉报警
def dingding_alert(data):
    headers = {'Content-Type':'application/json;charset=utf-8'}
    webhook = "https://oapi.dingtalk.com/robot/send?access_token=2d4ec3bfee21d6f08097b47316f7dfaf555bdf405561f4996d17aafc668ed5b5"
    #webhook = "https://oapi.dingtalk.com/robot/send?access_token=6fe7bf68c04b7af45a448befd65e2270f9a5c6058f215cdac05cc85d642a50e9"
    requests.post(url=webhook,data=json.dumps(data),headers=headers)

def get_data(text_content):
    text = {
            "msgtype":"text",
            "text":{
                "content":text_content
                },
            }
    return text



# 连接到数据库
client = pymongo.MongoClient('mongodb://cmdb:cmdb123456@172.18.132.106:27017/')
db = client['cmdb']
tasks = db['model_data']

current_date = datetime.datetime.now()
task_list_url = "https://cmdb.hkbge.com/o/cmdb/#/resource/repository/resourceDetail/task_alert/%E5%90%88%E8%A7%84%E5%91%A8%E6%9C%9F%E4%BB%BB%E5%8A%A1"

#查询任务列表
for task in tasks.find({"data.task_alert_name": {"$exists": True}}):
    
    last_execution = datetime.datetime.strptime(task['data']['task_alert_last_execution'],'%Y-%m-%d %H:%M:%S')
    next_execution = datetime.datetime.strptime(task['data']['task_alert_next_execution'],'%Y-%m-%d %H:%M:%S')

    print (current_date)
    print (next_execution)

    if current_date >= next_execution and task['data']['task_alert_status'] == '待执行':
        if task['data']['task_alert_frequency'] == '季度':
            next_execution = last_execution + datetime.timedelta(days=90)
        elif task['data']['task_alert_frequency'] == '月度':
            next_execution = last_execution + datetime.timedelta(days=30)
        elif task['data']['task_alert_frequency'] == '年度':
            next_execution = last_execution + datetime.timedelta(days=360)

        message = """ 测试！！！！！
            合规周期任务-事件提醒
                
            任务名称：%s
            任务频次：%s
            任务状态：%s
            任务链接：%s

            如果任务已完成,请修改任务状态.选中任务》编辑》任务状态》已完成  %s
            """ % (task['data']['task_alert_task_name'],task['data']['task_alert_frequency'],task['data']['task_alert_status'],task['data']['task_alert_task_url'],task_list_url)

        data = get_data(message)
        dingding_alert(data)


        #tasks.update_one({'_id': task['_id']}, {'$set': {'data.task_alert_last_execution': current_date, 'data.task_alert_next_execution': next_execution, 'data.task_alert_status': '已完成'}})

    elif current_date >= last_execution and current_date < next_execution and task['data']['task_alert_status'] == '已完成':
        # 标记任务状态
        tasks.update_one({'_id': task['_id']}, {'$set': {'data.task_alert_status': '待执行'}})

# 关闭数据库连接
client.close()
