redis-cli -h exchange-match-test.p1rmlf.clustercfg.ape1.cache.amazonaws.com -p 6379 -c  -n 0 keys "*" | while read key
do
    redis-cli -h exchange-match-test.p1rmlf.clustercfg.ape1.cache.amazonaws.com -p 6379 -c -n 0 --raw dump $key | perl -pe 'chomp if eof' | redis-cli -h exchange-match-backup.p1rmlf.clustercfg.ape1.cache.amazonaws.com -p 6379 -c  -n 0 -x restore $key 0
    echo "migrate key $key"
done

