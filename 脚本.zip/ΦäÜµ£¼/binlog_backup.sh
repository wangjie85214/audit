#!/bin/bash
#Description: 增量备份mysql binlog,上传至s3存储
#Author:WangJie
#Date:2023-09-07

source /etc/profile

# MySQL连接参数
MYSQL_HOST="172.18.135.141"
MYSQL_PORT="3306"
MYSQL_USER="root"
MYSQL_PASSWORD="6OeILca2x0c35ga"

# S3存储桶信息
S3_BUCKET="bge-prod-backup"
S3_PREFIX="binlog/3306"

# 获取当前日期
CURRENT_DATE=$(date +"%Y-%m-%d")

# 获取MySQL binlog日志文件路径
BINLOG_PATH=$(mysql -h $MYSQL_HOST -P $MYSQL_PORT -u $MYSQL_USER -p$MYSQL_PASSWORD -e "SHOW VARIABLES LIKE 'log_bin_basename'" | awk '$2 {print $2}' | sed -n '2,1p' )

# 获取最新的binlog文件名
LATEST_BINLOG=$(mysql -h $MYSQL_HOST -P $MYSQL_PORT -u $MYSQL_USER -p$MYSQL_PASSWORD -e "SHOW MASTER STATUS" | awk '$1 {print $1}' | sed -n '2,1p')

# 备份当天生成的所有binlog文件，但不包括最新的binlog文件
for FILE in $(ls -1 $BINLOG_PATH.*)
do
  FILE_NAME=$(basename $FILE)

  # 排除最新的binlog文件
  if [[ $FILE_NAME == *$LATEST_BINLOG ]]; then
    continue
  fi

  # 构建目标S3对象的键
  S3_KEY="$S3_PREFIX/$FILE_NAME"

  # 检查binlog文件是否已存在于S3桶中
  EXISTING_BINLOG=$(aws s3api list-objects --bucket $S3_BUCKET --prefix $S3_KEY --query "Contents[].Key" --output text)


  if [ $EXISTING_BINLOG == 'None' ]; then
   # 上传binlog文件到S3桶
    aws s3 cp $FILE s3://$S3_BUCKET/$S3_KEY
    echo $CURRENT_DATE": Successfully backed up binlog file $FILE_NAME to S3."
  else
    echo $CURRENT_DATE": Binlog file $FILE_NAME already exists in S3. Skipping backup."
  fi








done
