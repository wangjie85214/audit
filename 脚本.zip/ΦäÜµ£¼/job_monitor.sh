#!/bin/bash

match_orders=`/data/flink/bin/flink list |grep match_orders_139 |awk -F: '{print $4}'`
sleep 10
echo $match_orders >>/tmp/job.log
if [ -z $match_orders ]
then
  curl -XPOST -s -L  'https://oapi.dingtalk.com/robot/send?access_token=2d4ec3bfee21d6f08097b47316f7dfaf555bdf405561f4996d17aafc668ed5b5'    -H 'Content-Type: application/json' -H "charset:utf-8"  -d '{"msgtype": "text","text": { "content": " job告警 match_orders_139"}}'

fi


order_fulfillment=`/data/flink/bin/flink list |grep order_fulfillment_139 |awk -F: '{print $4}'`
sleep 10
echo $order_fulfillment>>/tmp/job.log
if [ -z $order_fulfillment ]
then
  echo "job 中断"
  curl -XPOST -s -L  'https://oapi.dingtalk.com/robot/send?access_token=2d4ec3bfee21d6f08097b47316f7dfaf555bdf405561f4996d17aafc668ed5b5'    -H 'Content-Type: application/json' -H "charset:utf-8"  -d '{"msgtype": "text","text": { "content": " job告警 order_fulfillment_139"}}'
fi


bill=`/data/flink/bin/flink list |grep bill_139 |awk -F: '{print $4}'`
sleep 10
echo $bill>>/tmp/job.log
if [ -z $bill ]
then
  echo "job 中断"
  curl -XPOST -s -L  'https://oapi.dingtalk.com/robot/send?access_token=2d4ec3bfee21d6f08097b47316f7dfaf555bdf405561f4996d17aafc668ed5b5'    -H 'Content-Type: application/json' -H "charset:utf-8"  -d '{"msgtype": "text","text": { "content": " job告警 bill_139"}}'
fi


