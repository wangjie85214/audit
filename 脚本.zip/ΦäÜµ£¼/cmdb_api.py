#!/usr/bin/env python3
# coding:utf8
'''
python update_director.py
'''

import requests
import sys
import argparse
import urllib3
import os

paas_domain = "https://cmdb.hkbge.com/"
paas_username = "admin"
paas_password = "OpscTyxz6459"

# 定义api请求的通用参数
app_code = "cmdb"
bk_app_secret = "eee5b34e-fc09-11ea-9e6a-00163e105ceb"

# 定义api请求的接口参数
component = "get_all_host"
model_code = "CLOUD_SERVER"

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class OpsAnyApi:
    def __init__(self, paas_domain, username, password):
        self.paas_domain = paas_domain
        self.session = requests.Session()
        self.session.headers.update({'referer': paas_domain})
        self.session.verify = False
        self.login_url = self.paas_domain + "/login/"
        self.csrfmiddlewaretoken = self.get_csrftoken()
        self.username = username
        self.password = password
        self.token = self.login()

    def get_csrftoken(self):
        try:
            resp = self.session.get(self.login_url, verify=False)
            if resp.status_code == 200:
                return resp.cookies["bklogin_csrftoken"]
            else:
                return ""
        except:
            return ""

    def login(self):
        try:
            login_form = {
                'csrfmiddlewaretoken': self.csrfmiddlewaretoken,
                'username': self.username,
                'password': self.password
            }
            resp = self.session.post(self.login_url, data=login_form, verify=False)
            if resp.status_code == 200:
                return self.session.cookies.get("bk_token")
            return ""
        except:
            return False

    def execute_api(self):
        API = f"{self.paas_domain}api/c/compapi/{app_code}/{component}/?bk_app_code={app_code}&bk_app_secret={bk_app_secret}&model_code={model_code}&bk_username=admin"
        # 获取api数据
        res = self.session.get(API)
        print(res.json())

        try:
            if res.status_code == 200 and res.json().get("code") == 200:
                return True
            raise Exception(res.json().get("message"))
        except Exception as e:
            print(f"Api error, error info: {str(e)}, api url: {API}")


def run():
    api_object = OpsAnyApi(paas_domain, paas_username, paas_password)
    #api_object.execute_api(app_code, component)
    api_object.execute_api()


if __name__ == '__main__':
    run()

