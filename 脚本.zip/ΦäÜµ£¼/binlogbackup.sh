#!/bin/bash
#Description: 增量备份mysql binlog
#Author:WangJie
#Date:2022-02-25
source /etc/profile
#ip=`/usr/sbin/ip addr|grep -A 2 'state UP'|tail -n 1|awk '{print $2}'|awk -F'/' '{print $1}'|tr '.' '-'`
#remotedir=/data/mysqlbackup/binlogbackup/$ip
bakdir=/data/backup/binlog
bindir3306=/data/mysql/data
bindir3307=/data/mysql8_apollo_case/data
bindir3308=/data/mysql8_blockchain_apollo/data
logfile=/tmp/binlog_bak.log
binfile3306=/data/mysql/data/mysql-bin.index
binfile3307=/data/mysql8_apollo_case/data/mysql-bin.index
binfile3308=/data/mysql8_blockchain_apollo/data/mysql-bin.index
/usr/local/mysql/bin/mysqladmin -uroot -p'6OeILca2x0c35ga' flush-logs
/usr/local/mysql/bin/mysqladmin -uroot -p'6OeILca2x0c35ga' -S /tmp/mysql8_apollo_case.sock -P3307 flush-logs
/usr/local/mysql/bin/mysqladmin -uroot -p'6OeILca2x0c35ga' -S /tmp/mysql8_blockchain_apollo.sock -P3308 flush-logs

#3306
counter=`wc -l $binfile3306 | awk '{print $1}'`
nextnum=0
for file in `cat $binfile3306`
do
  base=`basename $file`
  nextnum=`expr $nextnum + 1`
  if [ $nextnum -eq $counter ]
    then
        echo $base skip! >>$logfile
    else
        dest=$bakdir/3306/$base
        if (test -e $dest)
        then
            echo $base exist! >>$logfile
        else
            cp $bindir3306/$base $bakdir/3306
	    aws s3api put-object --bucket qhxc-dbbackup-dump --key binlog/3306/$base --server-side-encryption AES256 --body $bindir3306/$base
            echo $base copying >>$logfile
        fi
  fi
done
echo `date +"%Y年%m月%d日 %H:%M:%S"` Backup success!>>$logfile

#3307
counter=`wc -l $binfile3307 | awk '{print $1}'`
nextnum=0
for file in `cat $binfile3307`
do
  base=`basename $file`
  nextnum=`expr $nextnum + 1`
  if [ $nextnum -eq $counter ]
    then
        echo $base skip! >>$logfile
    else
        dest=$bakdir/3307/$base
        if (test -e $dest)
        then
            echo $base exist! >>$logfile
        else
            cp $bindir3307/$base $bakdir/3307
	    aws s3api put-object --bucket qhxc-dbbackup-dump --key binlog/3307/$base --server-side-encryption AES256 --body $bindir3307/$base
            echo $base copying >>$logfile
        fi
  fi
done
echo `date +"%Y年%m月%d日 %H:%M:%S"` Backup success!>>$logfile

#3308
counter=`wc -l $binfile3308 | awk '{print $1}'`
nextnum=0
for file in `cat $binfile3308`
do
  base=`basename $file`
  nextnum=`expr $nextnum + 1`
  if [ $nextnum -eq $counter ]
    then
        echo $base skip! >>$logfile
    else
        dest=$bakdir/3308/$base
        if (test -e $dest)
        then
            echo $base exist! >>$logfile
        else
            cp $bindir3308/$base $bakdir/3308
	    aws s3api put-object --bucket qhxc-dbbackup-dump --key binlog/3308/$base --server-side-encryption AES256 --body $bindir3308/$base
            echo $base copying >>$logfile
        fi
  fi
done
echo `date +"%Y年%m月%d日 %H:%M:%S"` Backup success!>>$logfile
