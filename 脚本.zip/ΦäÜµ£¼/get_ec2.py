#!/usr/bin/python3
# encoding=utf-8

import boto3
import json
import pymongo
import datetime

class CustomEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, datetime):
            return o.isoformat()
        return super().default(o)


def get_ec2_instance_info():
    # 指定AWS访问密钥
    aws_access_key_id = 'AKIAYAD2R6SDNRUJ6AJ7'
    aws_secret_access_key = '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'
    region_name = 'ap-east-1'

    # 创建EC2客户端
    ec2_client = boto3.client('ec2', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key, region_name=region_name)

    # 描述EC2实例
    response_instances = ec2_client.describe_instances()

    # 获取所有实例类型
    response_instance_types = ec2_client.describe_instance_types()

    # 获取EC2实例信息
    instance_response = ec2_client.describe_instances()
    volume_response = ec2_client.describe_volumes()

    # 解析并构建输出格式
    data_info = []
    unique_fields = ["CLOUD_SERVER_name"]

    volume_data = {}
    for volume in volume_response['Volumes']:
        volume_id = volume['VolumeId']
        volume_size = volume['Size']
        volume_data[volume_id] = volume_size

    for reservation in instance_response['Reservations']:
        for instance in reservation['Instances']:
            instance_id = instance['InstanceId']
            instance_type = instance['InstanceType']
            private_ip = instance['PrivateIpAddress']
            state = instance['State']['Name']
         #   launch_time = instance['LaunchTime']
            hostname = get_instance_hostname(instance)
            availability_zone = instance['Placement']['AvailabilityZone']
            cpu = instance['CpuOptions']['ThreadsPerCore']
        #    disk = get_instance_disk(instance, volume_data)

            operating_system = instance['Platform'] if 'Platform' in instance else 'Linux'

        # 设置label
            set_cmdb_label(instance)
            
            # 查找实例类型的内存信息
            for instance_type_info in response_instance_types['InstanceTypes']:
                if instance_type_info['InstanceType'] == instance_type:
                    instance_memory_size = instance_type_info['MemoryInfo']['SizeInMiB']
                    break
            
           # label = get_instance_label(instance)

            instance_info = {
                "CLOUD_SERVER_name": instance_id,
                "CLOUD_SERVER_VISIBLE_NAME": hostname,
                "CLOUD_SERVER_INSTANCE_NAME": hostname,
                "CLOUD_SERVER_HOSTNAME": hostname,
              #  "CLOUD_SERVER_IS_DELETE": 0,
                "CLOUD_SERVER_GROUP": '',
                "CLOUD_SERVER_INSTANCE_ID": instance_id,
              #  "EC2_instance_type": instance_type,
                "CLOUD_SERVER_INTERNAL_IP": private_ip,
              #  "CLOUD_SERVER_RUN_STATUS": state,
              #  "EC2_launch_time": launch_time,
                "CLOUD_SERVER_IN_AZ": availability_zone,
                "CLOUD_SERVER_CPU_NUM": cpu,
              #  "EC2_disk": disk,
                "CLOUD_SERVER_OS_TYPE": operating_system,
                "CLOUD_SERVER_MEMORY": instance_memory_size,
              #  "CLOUD_SERVER_LABEL_LIST": label
            }

            data_info.append(instance_info)

    output = {
        "data_info": data_info,
        "unique_fields": unique_fields
    }

    # 输出为JSON格式
    output_json = json.dumps(output, indent=4, cls=CustomEncoder)
    print(output_json)

def get_instance_disk(instance, volume_data):
    # 获取实例的磁盘空间信息
    disk = []

    for block_device in instance['BlockDeviceMappings']:
        device_name = block_device['DeviceName']
        ebs = block_device.get('Ebs')
        if ebs:
            volume_id = ebs['VolumeId']
            volume_size = volume_data.get(volume_id, 'N/A')
            disk.append(f"{device_name}: {volume_size}GB")
        else:
            disk.append(f"{device_name}: N/A")

    return disk


def get_instance_hostname(instance):
    # 获取实例的主机名（从标签中获取）
    for tag in instance.get('Tags', []):
        if tag['Key'] == 'Name':
            return tag['Value']

    return 'N/A'

def get_instance_label(instance):
    # 获取实例的标签
    for tag in instance.get('Tags', []):
        if tag['Key'] != 'Name':
            return tag['Key'],tag['Value']

# 获取aws上的label同步到cmdb
def set_cmdb_label(instance):

    # 连接cmdb的mongodb数据库
    client = pymongo.MongoClient('mongodb://cmdb:cmdb123456@172.18.132.106:27017/')
    db = client['cmdb']
    label_key = db['label_key_model']
    label_value = db['label_value_model']
    model_data = db['model_data']

    # 获取当前日期和时间
    current_time = datetime.datetime.now()

    # 获取已有文档的数量
    id_counter = label_value.count_documents({})

    for tag in instance.get('Tags', []):
        if tag['Key'] == 'application':
            instancename = get_instance_hostname(instance)


            # 构建要插入的文档
            label_value_doc = {
                    "_id": id_counter,
                    "updated_at": current_time,
                    "created_at": current_time,
                    "value_name": tag['Value'],
                    "key": 6 # 6为application,在label_key_model表中存储
                }
            
            value = [label_value.find_one({"value_name": tag['Value']}, {"_id": 1})['_id']]

            if value:
                label_value.update_one({ "value_name": tag['Value']},{'$set': { "updated_at": current_time } } )
            else:
                id_counter = label_value.count_documents({}) + 1  # 获取当前文档数量并加1，作为新的_id

                label_value.insert_one({
                    "_id": id_counter,
                    "updated_at": current_time,
                    "created_at": current_time,
                    "value_name": tag['Value'], 
                    "key": 6 # 6为application,在label_key_model表中存储
                })


            # 更新instance实例的label标签
            model_data.update_one({"data.CLOUD_SERVER_HOSTNAME":instancename},{'$set': {'label_list' : value }} )



get_ec2_instance_info()
