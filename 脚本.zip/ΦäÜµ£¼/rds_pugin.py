#encoding=utf-8
import boto3
import json

def get_rds_instance_info():
    # 指定AWS访问密钥
    aws_access_key_id = 'AKIAYAD2R6SDNRUJ6AJ7'
    aws_secret_access_key = '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'
    region_name = 'ap-east-1'

    # 创建RDS客户端
    rds_client = boto3.client('rds', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key, region_name=region_name)

    # 获取RDS实例信息
    response = rds_client.describe_db_instances()

    # 解析并构建输出格式
    data_info = []
    unique_fields = ["MySQL_rds_id"]

    for db_instance in response['DBInstances']:
        instance_id = db_instance['DBInstanceIdentifier']
        engine = db_instance['Engine']
        engine_version = db_instance['EngineVersion']
        cpu = f"{db_instance['AllocatedStorage']}C"
        memory = f"{db_instance['DBInstanceClass']}G"
        disk = f"{db_instance['AllocatedStorage']}GiB"
        status = db_instance['DBInstanceStatus']

        instance_info = {
                "MySQL_rds_id": instance_id,
                "MySQL_rds_version": engine_version,
                "MySQL_rds_cpu": cpu,
                "MySQL_rds_memory": memory,
                "MySQL_rds_disk": disk,
                "MySQL_rds_status": status
            }

        data_info.append(instance_info)

    output = {
            "data_info": data_info,
            "unique_fields": unique_fields
        }

    # 输出为JSON格式
    output_json = json.dumps(output, indent=4)
    print(output_json)

get_rds_instance_info()

