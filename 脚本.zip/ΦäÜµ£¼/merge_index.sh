#!/bin/bash
#Description:es索引分段合并
#Author:WangJie
#Date:2022-12-12

set -e
source /etc/profile

es_user=elastic
es_passwd=2STTKpSTtSeR
es_host='192.168.13.108:9200'

curl -XPOST "http://$es_user:$es_passwd@$es_host/match_orders/_forcemerge?max_num_segments=1"
curl -XPOST "http://$es_user:$es_passwd@$es_host/order_fulfillment/_forcemerge?max_num_segments=1"
curl -XPOST "http://$es_user:$es_passwd@$es_host/bill/_forcemerge?max_num_segments=1"
