import redis,sys

# Source and destination instance details
source_host = 'master.exchange-test.p1rmlf.ape1.cache.amazonaws.com'
source_port = 6379
source_password = 'CP687zdZ1I247ZDL'

destination_host = 'master.exchange-backup.p1rmlf.ape1.cache.amazonaws.com'
destination_port = 6379
destination_password = 'AHlkRDwF3ePdHTlw'

# Connect to the source and destination instances
source_redis = redis.Redis(host=source_host, port=source_port, password=source_password, ssl=True)
destination_redis = redis.Redis(host=destination_host, port=destination_port, password=destination_password, ssl=True)


# Get all keys from the source instance
keys = source_redis.keys('*')

# Migrate keys from source to destination instance
for key in keys:
    try:
        # Migrate key from source to destination instance
        value = source_redis.dump(key)
        destination_redis.restore(key, 0, value, replace=True)
        print(f"Key '{key}' migrated successfully.")

    except redis.RedisError as e:
        print(f"Failed to migrate key '{key}': {str(e)}")

# Disconnect from the instances
source_redis.close()
destination_redis.close()
