#!/bin/bash

# 连接MySQL数据库的信息
MYSQL_HOST="mysql-bge-test.cshckcbibsdx.ap-east-1.rds.amazonaws.com"
MYSQL_PORT="3306"
MYSQL_DATABASE="exchange"
MYSQL_USERNAME="admin"
MYSQL_PASSWORD="6OeILca2x0c35ga"

# 查询orders表中的最大id值
query="SELECT MAX(id) FROM orders;"
result=$(mysql -h$MYSQL_HOST -P$MYSQL_PORT -u$MYSQL_USERNAME -p$MYSQL_PASSWORD $MYSQL_DATABASE -se "$query")
max_id=$(echo $result | awk '{print $1}')

# 计算新的自增主键值
new_id=$((max_id + 1))

# 修改表的自增主键值
alter_query="ALTER TABLE orders AUTO_INCREMENT = $new_id;"
mysql -h$MYSQL_HOST -P$MYSQL_PORT -u$MYSQL_USERNAME -p$MYSQL_PASSWORD $MYSQL_DATABASE -se "$alter_query"

