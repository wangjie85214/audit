#!/bin/bash

src='master.exchange-test.p1rmlf.ape1.cache.amazonaws.com'
dst='master.exchange-backup.p1rmlf.ape1.cache.amazonaws.com'

redis-cli -h $src -a CP687zdZ1I247ZDL --tls -p 6379  -n 0 keys "*" | while read key
do
    redis-cli -h $src -a CP687zdZ1I247ZDL --tls -p 6379  -n 0 --raw dump $key | perl -pe 'chomp if eof' | redis-cli -h $dst -a AHlkRDwF3ePdHTlw --tls -p 6379 -n 0 -x restore $key 0
    echo "migrate key $key successful!"
done

