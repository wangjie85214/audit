#!/bin/bash

src='blockchain-test.p1rmlf.ng.0001.ape1.cache.amazonaws.com'
dst='blockchain-backup.p1rmlf.ng.0001.ape1.cache.amazonaws.com'

redis-cli -h $src -p 6379  -n 0 keys "*" | while read key
do
    redis-cli -h $src -p 6379  -n 0 --raw dump $key | perl -pe 'chomp if eof' | redis-cli -h $dst -p 6379 -n 0 -x restore $key 0
    echo "migrate key $key successful!"
done

