#!/bin/bash

src='clustercfg.exchange-match-uc-test.p1rmlf.ape1.cache.amazonaws.com'
dst='clustercfg.exchange-uc-backup.p1rmlf.ape1.cache.amazonaws.com'

redis-cli -h $src -a CP687zdZ1I247ZDL -c --tls -p 6379  -n 0 keys "*" | while read key
do
    redis-cli -h $src -a CP687zdZ1I247ZDL -c --tls -p 6379  -n 0 --raw dump $key | perl -pe 'chomp if eof' | redis-cli -h $dst -a AHlkRDwF3ePdHTlw -c --tls -p 6379 -n 0 -x restore $key 0
    echo "migrate key $key successful!"
done

