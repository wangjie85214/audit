#!/bin/bash
# Description: MySQL and MongoDB backup
# Creater: Wangjie
# CreatTime: 2023-06-14

source /etc/profile
dateid=$(date +"%Y%m%d")
backpath=/data/backup


HOST="172.18.132.106"
MYSQL_PASSWORD="OpsAny@2020"
MYSQL_PORT="3306"
MYSQL_USER="root"

MONGO_PORT="27017"
MONGO_USERNAME="root"
MONGO_PASSWORD="OpsAny@2020"

#backup MySQL
mysqldump -u$MYSQL_USER -p$MYSQL_PASSWORD -h$HOST -B bastion cmdb cmp control dashboard job opsany_paas opsany_proxy rbac workbench  | gzip > $backpath/mysql/backup_cmdb_mysql_${dateid}.sql.gz

#backup MongoDB
mongodump --host $HOST -u $MONGO_USERNAME -p $MONGO_PASSWORD --authenticationDatabase admin -d cmdb -o $backpath/mongodb/
mongodump --host $HOST -u $MONGO_USERNAME -p $MONGO_PASSWORD --authenticationDatabase admin -d cmp -o $backpath/mongodb/
mongodump --host $HOST -u $MONGO_USERNAME -p $MONGO_PASSWORD --authenticationDatabase admin -d job -o $backpath/mongodb/
mongodump --host $HOST -u $MONGO_USERNAME -p $MONGO_PASSWORD --authenticationDatabase admin -d workbench -o $backpath/mongodb/

cd $backpath/mongodb/
tar -zcvf backup_cmdb_mongodb_${dateid}.tar.gz *

#upload mongodb backup to S3
aws s3api put-object --bucket qhxc-dbbackup-dump --key cmdb/mongodb/backup_cmdb_mongodb_${dateid}.tar.gz --server-side-encryption AES256 --body backup_cmdb_mongodb_${dateid}.tar.gz

#upload mysql backup to S3
cd $backpath/mysql/
aws s3api put-object --bucket qhxc-dbbackup-dump --key cmdb/mysql/backup_cmdb_mysql_${dateid}.sql.gz --server-side-encryption AES256 --body backup_cmdb_mysql_${dateid}.sql.gz

#delete local file
rm -rf $backpath/mysql/*
rm -rf $backpath/mongodb/*
