#!/bin/bash
#Description: redis集群安装部署及集群初始化
#Author:WangJie
#Date:2022-11-09

local_ip=`ifconfig -a|grep inet|grep -v 127.0.0.1|grep -v inet6|awk '{print $2}'|tr -d "addr:"`
redis_server_cnt=`which redis-server | wc -l`
if [ $redis_server_cnt -ne 1 ]
 then
     echo "installing redis-server..."
     cd /opt/ && wget https://download.redis.io/releases/redis-6.2.7.tar.gz
     tar -zxvf redis-6.2.7.tar.gz
     mv redis-6.2.7 /usr/local/redis
     cd /usr/local/redis && make

fi

#创建数据目录、日志目录及配置文件目录

mkdir -p /data/storage/redis_cluster/data/7000

mkdir -p /data/storage/redis_cluster/data/7001

mkdir -p /data/storage/redis_cluster/data/7002

mkdir -p /data/storage/redis_cluster/data/7003

mkdir -p /data/storage/redis_cluster/data/7004

mkdir -p /data/storage/redis_cluster/data/7005

mkdir -p /data/storage/redis_cluster/etc

mkdir -p /data/storage/redis_cluster/logs

#创建配置文件
cat >/data/storage/redis_cluster/etc/7000.conf  <<EOF

daemonize yes
port 7000
cluster-enabled yes
logfile "/data/storage/redis_cluster/logs/redis.log"
dir /data/storage/redis_cluster/data/7000/
masterauth Q2f9YJci0dQn
requirepass Q2f9YJci0dQn

EOF

cat >/data/storage/redis_cluster/etc/7001.conf  <<EOF

daemonize yes
port 7001
cluster-enabled yes
logfile "/data/storage/redis_cluster/logs/redis.log"
dir /data/storage/redis_cluster/data/7001/
masterauth Q2f9YJci0dQn
requirepass Q2f9YJci0dQn

EOF

cat >/data/storage/redis_cluster/etc/7002.conf  <<EOF

daemonize yes
port 7002
cluster-enabled yes
logfile "/data/storage/redis_cluster/logs/redis.log"
dir /data/storage/redis_cluster/data/7002/
masterauth Q2f9YJci0dQn
requirepass Q2f9YJci0dQn

EOF

cat >/data/storage/redis_cluster/etc/7003.conf  <<EOF

daemonize yes
port 7003
cluster-enabled yes
logfile "/data/storage/redis_cluster/logs/redis.log"
dir /data/storage/redis_cluster/data/7003/
masterauth Q2f9YJci0dQn
requirepass Q2f9YJci0dQn

EOF

cat >/data/storage/redis_cluster/etc/7004.conf  <<EOF

daemonize yes
port 7004
cluster-enabled yes
logfile "/data/storage/redis_cluster/logs/redis.log"
dir /data/storage/redis_cluster/data/7004/
masterauth Q2f9YJci0dQn
requirepass Q2f9YJci0dQn

EOF

cat >/data/storage/redis_cluster/etc/7005.conf  <<EOF

daemonize yes
port 7005
cluster-enabled yes
logfile "/data/storage/redis_cluster/logs/redis.log"
dir /data/storage/redis_cluster/data/7005/
masterauth Q2f9YJci0dQn
requirepass Q2f9YJci0dQn

EOF

#启动redis-server
/usr/local/redis/src/redis-server /data/storage/redis_cluster/etc/7000.conf

/usr/local/redis/src/redis-server /data/storage/redis_cluster/etc/7001.conf

/usr/local/redis/src/redis-server /data/storage/redis_cluster/etc/7002.conf

/usr/local/redis/src/redis-server /data/storage/redis_cluster/etc/7003.conf

/usr/local/redis/src/redis-server /data/storage/redis_cluster/etc/7004.conf

/usr/local/redis/src/redis-server /data/storage/redis_cluster/etc/7005.conf

#配置集群
/usr/local/redis/src/redis-cli --cluster create $local_ip:7000 $local_ip:7001 $local_ip:7002 $local_ip:7003 $local_ip:7004 $local_ip:7005 --cluster-replicas 1 -a Q2f9YJci0dQn
