#!/bin/bash
#Description: bge预发环境mysql数据初始化
#Creater: Wangjie
#CreatTime: 2023-04-18

user=admin
password=6OeILca2x0c35ga
host=mysql-backend.cshckcbibsdx.ap-east-1.rds.amazonaws.com
host2=mysql-wallet.cshckcbibsdx.ap-east-1.rds.amazonaws.com
host3=mysql-wallet-order.cshckcbibsdx.ap-east-1.rds.amazonaws.com
host4=mysql-wallet-risk.cshckcbibsdx.ap-east-1.rds.amazonaws.com
host5=mysql-wallet-sign.cshckcbibsdx.ap-east-1.rds.amazonaws.com
host_new=mysql-bge-test.cshckcbibsdx.ap-east-1.rds.amazonaws.com
backupddlfile=/tmp/backup_ddl.sql

#导出表结构
mysqldump -u$user -h$host -p$password --set-gtid-purged=OFF -B asset_derive asset_management auth cms cosmos_finance cosmos_rates cosmos_transfer exchange file foundation_config kline_history mis property qhxc_callback qhxc_notice users xxl_job -d > $backupddlfile
mysqldump -u$user -h$host2 -p$password --set-gtid-purged=OFF -B wallet -d >> $backupddlfile
mysqldump -u$user -h$host3 -p$password --set-gtid-purged=OFF -B wallet_order -d >> $backupddlfile
mysqldump -u$user -h$host4 -p$password --set-gtid-purged=OFF -B wallet_risk -d >> $backupddlfile
mysqldump -u$user -h$host5 -p$password --set-gtid-purged=OFF -B wallet_sign -d >> $backupddlfile
#导出数据
mysqldump -u$user -h$host -p$password --set-gtid-purged=OFF auth app_code_info sys_menu sys_role sys_role_menu sys_user sys_user_role >/tmp/backup_auth_dml.sql
mysqldump -u$user -h$host -p$password --set-gtid-purged=OFF qhxc_notice business business_fun business_fun_template channel >>/tmp/backup_qhxc_notice_dml.sql
mysqldump -u$user -h$host -p$password --set-gtid-purged=OFF foundation_config change_version currency_net_type_config >>/tmp/backup_foundation_config_dml.sql
mysqldump -u$user -h$host -p$password --set-gtid-purged=OFF mis audit_config >>/tmp/backup_mis_dml.sql


#导入表结构到bge预发环境，需要登录到新的jumpserver服务器执行。


#更新数据
mysql -u$user -h$host_new -p$password -e "update foundation_config.change_version set biz_version = 1;"

#wallet 钱包数据初始化
mysql -u$user -h$host_new -p$password wallet -e "INSERT INTO best_block_height (id, created_at, updated_at, deleted_at, symbol, height) VALUES (1, '2022-01-17 19:36:11', '2022-06-02 16:27:53', NULL, 'ETH', 17065102),(2, '2022-01-17 19:36:11', '2022-06-02 16:27:28', NULL, 'BTC', 785764);"

mysql -u$user -h$host_new -p$password wallet -e "INSERT INTO chain_type_relation (id, created_at, updated_at, deleted_at, chain_id, symbol, relation_chain_id, relation_symbol, main_symbol) VALUES (1, '2022-04-28 11:11:17', '2022-04-28 11:11:17', NULL, '0', 'BTC', '0', 'BTC', 'BTC'),(2, '2022-04-28 11:11:18', '2022-04-28 11:11:18', NULL, '60', 'ETH', '60', 'ETH', 'ETH');"


