#!/bin/bash
#Description: 安装部署Archery平台
# Creater: Wangjie
# CreatTime: 2023-04-13

# 安装依赖
yum install libffi-devel wget gcc make zlib-devel openssl openssl-devel ncurses-devel openldap-devel gettext bzip2-devel xz-devel
cd /opt && wget "https://www.python.org/ftp/python/3.9.10/Python-3.9.10.tar.xz" 
tar -xvJf Python-3.9.10.tar.xz 
# 编译
cd Python-3.9.10 
./configure prefix=/usr/local/python3 
make && make install 
ln -fs /usr/local/python3/bin/python3 /usr/bin/python3 
ln -fs /usr/local/python3/bin/pip3 /usr/bin/pip3 
# virtualenv
pip3 install virtualenv -i https://mirrors.ustc.edu.cn/pypi/web/simple/ 
ln -fs /usr/local/python3/bin/virtualenv /usr/bin/virtualenv 

# 编译安装python的使用
virtualenv venv4archery --python=python3
# 切换python运行环境到虚拟环境
source venv4archery/bin/activate

cd /opt && wget "https://github.com/hhyo/archery/archive/v1.8.5.tar.gz"
tar -xzvf v1.8.5.tar.gz

# 安装系统依赖
yum -y install gcc gcc-c++ python-devel mysql-devel openldap-devel unixODBC-devel gettext

# 安装依赖库
mv Archery-1.8.5 /data/
cd /data/storage/Archery-1.8.5
pip3 install -r requirements.txt -i https://mirrors.ustc.edu.cn/pypi/web/simple/ 


#安装Inception
cd /opt && wget https://github.com/hanchuanchuan/goInception/releases/download/v1.3.0/goInception-linux-v1.3.0-68-g2f47aef.tar.gz
tar -zxvf goInception-linux-v1.3.0-68-g2f47aef.tar.gz
mkdir -p /data/storage/goInception
mv config /data/storage/goInception
mv goInception /data/storage/goInception

#安装mysql
#关闭firewalld防火墙服务，并且设置开机不要启动
service firewalld stop
systemctl disable firewalld

#下载mysql安装包、解压安装
cd /opt/ && wget https://dev.mysql.com/get/Downloads/MySQL-5.7/mysql-5.7.39-el7-x86_64.tar.gz
tar -zxvf mysql-5.7.39-el7-x86_64.tar.gz
mv mysql-5.7.39-el7-x86_64 /usr/local/mysql

#创建用户用户组
groupadd mysql
useradd -r -g mysql mysql

#创建data目录和logs目录
mkdir -p /data/storage/mysql/data/
mkdir -p /data/storage/mysql/logs
chown -R mysql:mysql /usr/local/mysql
chown -R mysql:mysql /data/storage/mysql/data
chown -R mysql:mysql /data/storage/mysql/logs

#配置my.cnf文件
cat  >/etc/my.cnf  <<EOF
[mysqld]
basedir=/usr/local/mysql
datadir=/data/storage/mysql/data
port = 3306
socket=/tmp/mysql.sock

symbolic-links=0
log-error=/data/storage/mysql/logs/mysqld.log
pid-file=/tmp/mysqld.pid
default-storage-engine=INNODB
log-bin=mysql-bin
binlog-format=ROW
binlog_cache_size=65536
expire_logs_days=2
server_id=1
max_connections=2000
max_connect_errors = 800
max_user_connections = 4000
innodb_flush_log_at_trx_commit = 1
innodb_buffer_pool_size = 1024M
innodb_log_file_size= 200M
back_log        = 2048
innodb_lock_wait_timeout        = 50
lock_wait_timeout =50
query_cache_size =0
thread_cache_size = 64
skip_name_resolve =1
slow_query_log =1
long_query_time=0.5
innodb_file_per_table=1
innodb_log_buffer_size=64M
innodb_flush_method=O_DIRECT
innodb_max_dirty_pages_pct=60
innodb_io_capacity_max=3000
innodb_io_capacity=1000
innodb_read_io_threads=4
innodb_write_io_threads=4
sql_mode        = STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION
log_output      = FILE
sync_binlog = 1
innodb_data_file_path = ibdata1:1024M:autoextend
character-set-server=utf8mb4
log_timestamps=SYSTEM
default-time_zone = '+8:00'

EOF

#初始化mysql数据库
/usr/local/mysql/bin/mysqld --initialize --user=mysql --basedir=/usr/local/mysql --datadir=/data/storage/mysql/data

#启动mysql数据库、创建账号并进行权限分配
#/usr/local/mysql/bin/mysqld_safe --user=mysql &

#开机服务启动设置
cp -a /usr/local/mysql/support-files/mysql.server /etc/init.d/mysql
chkconfig --add mysql

#启动mysq服务、账号权限
service mysql restart
temp_passwd=$(cat /data/storage/mysql/logs/mysqld.log |grep "temporary password"|awk '{print $NF}')
/usr/local/mysql/bin/mysql -uroot  -p$temp_passwd --connect-expired-password -e "set password=password('qhxc@021');grant all privileges on *.* to 'root'@'%' identified by 'qhxc@021';flush privileges;"


#安装redis
cd /opt/ && wget https://download.redis.io/releases/redis-6.2.7.tar.gz
tar -zxvf redis-6.2.7.tar.gz
mv redis-6.2.7 /usr/local/redis
cd /usr/local/redis && make

#创建data,logs,etc目录
mkdir -p /data/storage/redis/data
mkdir -p /data/storage/redis/logs
mkdir -p /data/storage/redis/etc

#生成配置文件
cat  >/data/storage/redis/etc/redis.conf  <<EOF
requirepass Q2f9YJci0dQn
protected-mode no
port 6379
tcp-backlog 511
timeout 0
tcp-keepalive 300
daemonize yes
supervised no
pidfile /var/run/redis_6379.pid
loglevel notice
logfile /data/storage/redis/logs/redis.log
databases 16
always-show-logo yes
save 900 1
save 300 10
save 60 10000
stop-writes-on-bgsave-error yes
rdbcompression yes
rdbchecksum yes
dbfilename dump.rdb
dir /data/storage/redis/data
replica-serve-stale-data yes
replica-read-only yes
repl-diskless-sync no
repl-diskless-sync-delay 5
repl-disable-tcp-nodelay no
replica-priority 100
lazyfree-lazy-eviction no
lazyfree-lazy-expire no
lazyfree-lazy-server-del no
replica-lazy-flush no
appendonly no
appendfilename "appendonly.aof"
appendfsync everysec
no-appendfsync-on-rewrite no
auto-aof-rewrite-percentage 100
auto-aof-rewrite-min-size 64mb
aof-load-truncated yes
aof-use-rdb-preamble yes
lua-time-limit 5000
slowlog-log-slower-than 10000
slowlog-max-len 128
latency-monitor-threshold 0
notify-keyspace-events ""
hash-max-ziplist-entries 512
hash-max-ziplist-value 64
list-max-ziplist-size -2
list-compress-depth 0
set-max-intset-entries 512
zset-max-ziplist-entries 128
zset-max-ziplist-value 64
hll-sparse-max-bytes 3000
stream-node-max-bytes 4096
stream-node-max-entries 100
activerehashing yes
client-output-buffer-limit normal 0 0 0
client-output-buffer-limit replica 256mb 64mb 60
client-output-buffer-limit pubsub 32mb 8mb 60
hz 10
dynamic-hz yes
aof-rewrite-incremental-fsync yes
rdb-save-incremental-fsync yes

EOF

#启动redis服务
/usr/local/redis/src/redis-server /data/storage/redis/etc/redis.conf

