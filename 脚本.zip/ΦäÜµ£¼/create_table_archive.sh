#!/bin/bash
#Description: 每年初，一次性自动创建以年月为结尾的归档表,如bill_2023_1,bill_2023_2
#Author:WangJie
#Date:2022-09-22

source /etc/profile

year=`date +'%Y'`
month=`date +'%m'|sed 's/0//g' `

user=root
password='qhxc@021'
dbname=test
host=192.168.10.200
port=3306

s_bill=bill
t_bill=bill_${year}_${month}

tables=(orders match_orders bill)

for t in ${tables[*]}
do
  for ((i=1;i<=12;i++));
    do
      mysql -u$user -h$host -p$password -P$port $dbname -e "create table ${t}_${year}_${i} like ${t};"
  done
done
