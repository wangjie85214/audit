set 'execution.savepoint.path' = '/data/flink/checkpoints/bill_139/9f6a9f5e88084ea20abb41627cce4288/chk-516' 
SET 'pipeline.name' = 'bill_139';
set 'state.checkpoints.dir' = 'file:///data/flink/checkpoints/bill_139';
set 'execution.checkpointing.interval' = '600000';

create database `default_catalog`.`exchange`;
CREATE TABLE IF NOT EXISTS `default_catalog`.`exchange`.`bill_src` (
    `id` BIGINT NOT NULL,
    `symbol` STRING NOT NULL,
    `refer_id` STRING NOT NULL,
    `refer_id2` STRING NOT NULL,
    `type` TINYINT NOT NULL,
    `action` TINYINT NOT NULL,
    `af` TINYINT NOT NULL,
    `user_id` BIGINT NOT NULL,
    `broker_id` INT NOT NULL,
    `pair_code` STRING NOT NULL,
    `deal_side` TINYINT NOT NULL,
    `delta` string NOT NULL,
    `before_assets` string NOT NULL,
    `after_assets` string NOT NULL,
    `fee` string NOT NULL,
    `notes` STRING NOT NULL,
    `create_on` TIMESTAMP(3),
    `update_on` TIMESTAMP(3),
    PRIMARY KEY(`id`)
    NOT ENFORCED
) with (
    'hostname' = '192.168.13.139',
    'port' = '3306',
    'username' = 'root',
    'password' = 'qhxc@021',
    'database-name' = 'exchange',
    'table-name' = 'bill',
    'connector' = 'mysql-cdc',
    'server-time-zone' = 'Asia/Shanghai',
    'server-id' = '5402'
    
);
CREATE TABLE IF NOT EXISTS `default_catalog`.`exchange`.`bill_sink` (
    `id` BIGINT NOT NULL,
    `symbol` STRING NOT NULL,
    `refer_id` STRING NOT NULL,
    `refer_id2` STRING NOT NULL,
    `type` TINYINT NOT NULL,
    `action` TINYINT NOT NULL,
    `af` TINYINT NOT NULL,
    `user_id` BIGINT NOT NULL,
    `broker_id` INT,
    `pair_code` STRING,
    `deal_side` TINYINT,
    `delta` STRING,
    `before_assets` STRING,
    `after_assets` STRING,
    `fee` STRING,
    `notes` STRING NOT NULL,
    `create_on` TIMESTAMP(3) ,
    `update_on` TIMESTAMP(3) ,
    PRIMARY KEY(`id`)
    NOT ENFORCED
) WITH (
    'connector' = 'elasticsearch-7',
    'hosts' = 'http://192.168.13.108:9200',
    'username' = 'elastic',
    'password' = '2STTKpSTtSeR',
    'index' = 'bill'
);
insert into `default_catalog`.`exchange`.`bill_sink` (id,symbol,refer_id,refer_id2,type,action,af,user_id,broker_id,pair_code,deal_side,delta,before_assets,after_assets,fee,notes, create_on, update_on) select id,symbol,refer_id,refer_id2,type,action,af,user_id,broker_id,pair_code,deal_side,delta,before_assets,after_assets,fee,notes, create_on, update_on from `default_catalog`.`exchange`.`bill_src` where action=3;

