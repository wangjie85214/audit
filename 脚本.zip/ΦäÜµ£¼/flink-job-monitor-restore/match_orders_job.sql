SET 'pipeline.name' = 'match_orders_139';
set 'state.checkpoints.dir' = 'file:///data/flink/checkpoints/match_orders_139';
set 'execution.checkpointing.interval' = '600000';


create database `default_catalog`.`exchange`;
CREATE TABLE IF NOT EXISTS `default_catalog`.`exchange`.`match_orders_src` (
    `id` BIGINT,
    `order_id` BIGINT ,
    `oppo_order_id` BIGINT ,
    `user_id` BIGINT ,
    `broker_id` INT ,
    `pair_code` STRING ,
    `mr_id` BIGINT ,
    `clazz` INT ,
    `system_type` INT ,
    `side` INT ,
    `deal_side` INT ,
    `entrust_price` STRING ,
    `filled_amount` STRING ,
    `price` STRING ,
    `unfilled_amount` STRING ,
    `deal_status` INT ,
    `order_status` INT ,
    `bill_status` INT ,
    `ext` STRING ,
    `create_time` TIMESTAMP(3) ,
    `update_time` TIMESTAMP(3) ,
    PRIMARY KEY(`id`)
    NOT ENFORCED
) with (
    'hostname' = '192.168.13.139',
    'port' = '3306',
    'username' = 'root',
    'password' = 'qhxc@021',
    'database-name' = 'exchange',
    'table-name' = 'match_orders',
    'connector' = 'mysql-cdc',
    'server-time-zone' = 'Asia/Shanghai',
    'server-id' = '5400'
);
CREATE TABLE IF NOT EXISTS `default_catalog`.`exchange`.`match_orders_sink` (
    `id` BIGINT ,
    `order_id` BIGINT ,
    `oppo_order_id` BIGINT ,
    `user_id` BIGINT ,
    `broker_id` INT ,
    `pair_code` STRING ,
    `mr_id` BIGINT ,
    `clazz` INT ,
    `system_type` INT ,
    `side` INT ,
    `deal_side` INT ,
    `entrust_price` STRING ,
    `filled_amount` STRING ,
    `price` STRING ,
    `unfilled_amount` STRING ,
    `deal_status` INT ,
    `order_status` INT ,
    `bill_status` INT ,
    `ext` STRING ,
    `create_time` TIMESTAMP(3) ,
    `update_time` TIMESTAMP(3) ,
    PRIMARY KEY(`id`)
    NOT ENFORCED
) WITH (
    'connector' = 'elasticsearch-7',
    'hosts' = 'http://192.168.10.127:9200',
    'username' = 'elastic',
    'password' = '2STTKpSTtSeR',
    'index' = 'match_orders'
);

insert into `default_catalog`.`exchange`.`match_orders_sink` (id, order_id, oppo_order_id, user_id, broker_id, pair_code, mr_id, clazz, system_type, side, deal_side, entrust_price, filled_amount, price, unfilled_amount, deal_status, order_status, bill_status, ext, create_time, update_time) select id, order_id, oppo_order_id, user_id, broker_id, pair_code, mr_id, clazz, system_type, side, deal_side, entrust_price, filled_amount, price, unfilled_amount, deal_status, order_status, bill_status, ext, create_time, update_time from `default_catalog`.`exchange`.`match_orders_src`;

