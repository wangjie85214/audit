# -*- coding: utf-8 -*-
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

# 邮件发送方的信息
from_addr = 'opsadmin@hkva-inc.com'
password = '2QGuR4qUhMlz'
# 邮件接收方的信息
to_addrs = ['liangtt@hkva-inc.com','wangjie@hkva-inc.com', 'tony.yip@hke.holdings','kathy.tsang@hke.holdings','irene.fung@hke.holdings','priscilla.lee@hke.holdings']
# 邮件主题和正文
subject = '数据导出'
body = '上周数据已导出，请查收附件。'
# 附件的路径和名称
attachment_path = '/tmp/data_export/data.zip'
attachment_name = 'data.zip'

# 创建邮件对象
msg = MIMEMultipart()
msg['From'] = from_addr
msg['To'] = ', '.join(to_addrs)
msg['Subject'] = subject
# 添加邮件正文
msg.attach(MIMEText(body, 'plain'))

# 添加附件
with open(attachment_path, 'rb') as f:
    attachment = MIMEApplication(f.read(), _subtype='zip')
    attachment.add_header('Content-Disposition', 'attachment', filename=attachment_name)
    msg.attach(attachment)

# 发送邮件
with smtplib.SMTP('smtp.office365.com', 587) as smtp:
    smtp.starttls()
    smtp.login(from_addr, password)
    smtp.sendmail(from_addr, to_addrs, msg.as_string())

