#encoding=utf-8
import ssl
import socket
from datetime import datetime, timedelta
from pymongo import MongoClient
import requests

def get_ssl_certificate_expiry(domain):
    # 建立安全连接
    context = ssl.create_default_context()
    with socket.create_connection((domain, 443)) as sock:
        with context.wrap_socket(sock, server_hostname=domain) as secure_sock:
            # 获取证书信息
            certificate = secure_sock.getpeercert()
    # 提取到期时间
    expiry_date_str = certificate['notAfter']
    expiry_date = datetime.strptime(expiry_date_str, "%b %d %H:%M:%S %Y %Z")
    return expiry_date


domain = "bg.exchange"

# 获取SSL证书到期时间
expiry_date = get_ssl_certificate_expiry(domain)
print (expiry_date)
# 更新到期时间到MongoDB数据库

