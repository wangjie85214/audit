#encoding=utf-8
import requests
from datetime import datetime, timedelta
import json
import ssl
import socket

domain = ['hkbge-inc.com','qihangxingchen.com','freeipa.hkva-inc.com','bg.exchange','bgwallet.io','zabbix.bgwallet.net','bg-exchange.com','zabbix.hkbge.com']

#domain = ['hkbge-inc.com','qihangxingchen.com']
#定义钉钉报警
def dingding_alert(data):
    headers = {'Content-Type':'application/json;charset=utf-8'}
    #webhook = "https://oapi.dingtalk.com/robot/send?access_token=2d4ec3bfee21d6f08097b47316f7dfaf555bdf405561f4996d17aafc668ed5b5"
    webhook = "https://oapi.dingtalk.com/robot/send?access_token=6fe7bf68c04b7af45a448befd65e2270f9a5c6058f215cdac05cc85d642a50e9"
    requests.post(url=webhook,data=json.dumps(data),headers=headers)

def get_data(text_content):
    text = {
            "msgtype":"text",
            "text":{
                "content":text_content
                },
            }
    return text

#获取域名的过期时间与SSL证书过期时间
def domain_expire_date():
	for domain_name in domain:
		context = ssl.create_default_context()
		with socket.create_connection((domain_name, 443)) as sock:
			with context.wrap_socket(sock, server_hostname=domain_name) as secure_sock:
				certificate = secure_sock.getpeercert()
       		# 提取SSL到期时间
		ssl_expire_date_str = certificate['notAfter']
		ssl_expire_date = datetime.strptime(ssl_expire_date_str, "%b %d %H:%M:%S %Y %Z")

		if ssl_expire_date:
			ssl_days_remaining = (ssl_expire_date - datetime.now()).days
			print (ssl_days_remaining)
			if ssl_days_remaining < 30:
				ssl_content = (f"域名 '{domain_name}' SSL证书将在 {ssl_days_remaining} 天后过期.")

			# 定义报警文本内容

				message = """
					域名到期通知
					%s 
					域名：%s
					SSL证书到期时间：%s
					""" % (ssl_content,domain_name,ssl_expire_date)
				data = get_data(message)
				dingding_alert(data)

if __name__ == '__main__':
    domain_expire_date()

