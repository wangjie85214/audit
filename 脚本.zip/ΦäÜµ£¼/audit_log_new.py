#!/usr/bin/python3
import boto3
import os
import logging
import time
import pymysql
import pytz
from datetime import datetime
import re


#解析审计日志、入库
def parse_and_store_log_data(log_data):
    # 数据库连接参数
    db_host = '172.18.135.141'
    db_user = 'root'
    db_password = '6OeILca2x0c35ga'
    db_name = 'audit'

    # 建立数据库连接
    conn = pymysql.connect(host=db_host, user=db_user, password=db_password, database=db_name)

    # 正则表达式
    pattern = r'(\d{8} \d{2}:\d{2}:\d{2}),([^,]+),([^,]+),([^,]+),(\d+),(\d+),([^,]+),(.*?)$'

    try:
        # 创建游标对象
        cursor = conn.cursor()

        # 解析日志数据
        matches = re.findall(pattern, log_data,re.MULTILINE)

        for match in matches:
            timestamp = match[0]
            # 处理时间字段的格式为yyyy-mm-dd HH:mi:ss
            timestamp = timestamp[:4] + '-' + timestamp[4:6] + '-' + timestamp[6:8] + ' ' + timestamp[9:]
            # 将字符串转换为datetime对象
            utc_time = datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
            # 将时区从UTC转换为北京时区
            utc_timezone = pytz.timezone('UTC')
            beijing_timezone = pytz.timezone('Asia/Shanghai')
            beijing_time = utc_timezone.localize(utc_time).astimezone(beijing_timezone)
            # 将时间格式化为字符串
            timestamp = beijing_time.strftime("%Y-%m-%d %H:%M:%S")

            hostname = match[1].replace('ip-', '').replace('-', '.')
            username = match[2]
            source_ip = match[3]
            session_id = match[4]
            query_id = match[5]
          #  statement_type = match[6]
            database = match[7].split(',', 1)[0]

            # 提取查询语句
            operation = match[7].split(',',1)[1]
            sql_split = operation.rsplit(',', 3)
            operation = sql_split[-4].strip("'")
            statement_type = operation.split()[0]

            # 存储到数据库
            sql = "INSERT INTO audit_log (timestamp, hostname, username, source_ip, session_id, query_id, " \
                      "statement_type, database_name, operation) " \
                      "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
            cursor.execute(sql, (timestamp, hostname, username, source_ip, session_id, query_id,
                                  statement_type, database, operation))



        # 提交事务
        conn.commit()
        logging.info('日志数据已成功存储到数据库')

    except Exception as e:
        logging.error(f'存储日志数据时发生错误：{str(e)}')
        conn.rollback()

    finally:
        # 关闭数据库连接
        conn.close()

#实时读取下载RDS审计日志
def download_audit_logs(instance_identifier, log_file_name, marker=None):
    try:
        session = boto3.Session(
            aws_access_key_id='AKIAYAD2R6SDDNJ5TLFS',
            aws_secret_access_key='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',
            region_name='ap-east-1'
        )

        # 创建rds客户端
        rds_client = session.client('rds')

        while True:
            download_args = {
                'DBInstanceIdentifier': instance_identifier,
                'LogFileName': log_file_name,
                'NumberOfLines': 2000,
            }
            if marker:
                download_args['Marker'] = marker

            # 下载rds实例的审计日志 
            response = rds_client.download_db_log_file_portion(**download_args)

            if 'LogFileData' in response:
                log_data = response['LogFileData']
                
                # 解析日志并存储到数据库中
                parse_and_store_log_data(log_data)


                # 如果还有未处理完成的日志，继续
                if 'AdditionalDataPending' in response and response['AdditionalDataPending']:
                    marker = response['Marker']
            else:
                logging.error('未找到指定的审计日志文件')
                break

            time.sleep(1)  # 每次循环之间的延迟时间

    except Exception as e:
        logging.error(f'下载日志文件时发生错误：{str(e)}')

# 定义rds实例，日志文件名与存储目录
instance_id = 'mysql-backend'
log_filename = 'audit/server_audit.log'
#save_directory = '/data'

while True:
    download_audit_logs(instance_id, log_filename)
    time.sleep(10)

