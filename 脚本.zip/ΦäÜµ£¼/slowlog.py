# -*- coding: utf-8 -*-
import mysql.connector
import csv
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication


# MySQL数据库连接信息
db_config = {
    'host': '172.18.135.58',
    'user': 'root',
    'password': 'qhx@021008',
    'database': 'archery'
}

# 邮箱发送信息
email_config = {
    'sender_email': 'opsadmin@hkva-inc.com',
    'sender_password': '2QGuR4qUhMlz',
    'receiver_emails': ['wangjie@hkva-inc.com', 'wangjie214.cool@163.com'],
    'subject': '本周TOP慢SQL统计'
}

# 查询MySQL数据库中的数据，并将其写入CSV文件
def create_csv_file():
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute("select hostname_max,client_max,db_max,sample,ts_cnt,Query_time_pct_95 from mysql_slow_query_review_history where Query_time_pct_95 >= 0.5 and user_max='app' order by id limit 10")
    rows = cursor.fetchall()

    with open('data.csv', 'wb') as file:
        writer = csv.writer(file)
        writer.writerow([i[0] for i in cursor.description])  # 写入表头
        writer.writerows(rows)  # 写入数据
	file.write('\n')  # 手动添加换行符

    cursor.close()
    conn.close()

# 发送邮件，并将CSV文件作为附件发送
def send_email():
    create_csv_file()
    message = MIMEMultipart()
    message['From'] = email_config['sender_email']
    message['Subject'] = email_config['subject']

    for receiver_email in email_config['receiver_emails']:
        message['To'] = receiver_email
        message.attach(MIMEText('CSV file attached.'))

        with open('data.csv', 'rb') as file:
            attach_file = MIMEApplication(file.read(), _subtype='csv')
            attach_file.add_header('content-disposition', 'attachment', filename='data.csv')
            message.attach(attach_file)

        server = smtplib.SMTP('smtp.office365.com', 587)  # 这里以Gmail邮箱为例
        server.starttls()
        server.login(email_config['sender_email'], email_config['sender_password'])
        server.sendmail(email_config['sender_email'], receiver_email, message.as_string())
        server.quit()


if __name__ == '__main__':
    send_email()
