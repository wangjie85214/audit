# -*- coding: utf-8 -*-
#Description: 对备份文件进行备份检验、失败触发报警
#Author: WangJie
#Date: 2023-05-05
#Comment: 只需要修改today_backup_path、previous_backup_path、subject_msg 这三个变量的值即可。

import os
import requests
import json
import sys
import datetime
import socket

today = datetime.datetime.now().strftime('%Y%m%d')
yesterday = (datetime.datetime.now() + datetime.timedelta(days = -1)).strftime('%Y%m%d')

#获取主机名信息
hostname = socket.gethostname()

#修改以下三个变量的值,修改为自己设置的备份目录或备份文件名称

#1.今天的备份目录或备份文件
today_backup_path = '/data/backup/mysql/' + today + '/mysql_kline_history_' + today + '.sql.gz'
#2.昨天的备份目录或备份文件
previous_backup_path = '/data/backup/mysql/' + yesterday + '/mysql_property_' + yesterday + '.sql.gz'
#3.钉钉报警的主题描述内容
subject_msg = "mysql备份  "

#钉钉报警
def dingding_alert(data):

	#把消息提交给钉钉机器人
	headers = {'Content-Type':'application/json;charset=utf-8'}
#	webhook = "https://oapi.dingtalk.com/robot/send?access_token=2d4ec3bfee21d6f08097b47316f7dfaf555bdf405561f4996d17aafc668ed5b5"
	webhook = "https://oapi.dingtalk.com/robot/send?access_token=6fe7bf68c04b7af45a448befd65e2270f9a5c6058f215cdac05cc85d642a50e9"
	requests.post(url=webhook,data=json.dumps(data),headers=headers)

#定义钉钉报警文本格式
def get_data(text_content):
	text = {
		"msgtype":"text",
		"text":{
			"content":text_content
		},

	}
	return text


#定义函数，统计备份目录下所有备份文件的大小（一次备份存在多个文件的情况）
def get_size(backup_path):
	listsize = []
	filelist = os.listdir(backup_path)
	for filename in filelist:
		pathtmp = os.path.join(backup_path,filename)
		if os.path.isdir(pathtmp):
			get_size(pathtmp)
		elif os.path.isfile(pathtmp):
			filesize = os.path.getsize(pathtmp)
			listsize.append(filesize)
	
	#print('%s 目录中的文件总大小：%d 字节' % (backup_path, sum(listsize)))
	#print('%s 目录中的文件总大小: %.4f MB' % (backup_path, (sum(listsize)/1024/1024)))
	#print('%s 目录中的文件总大小: %.4f GB' % (backup_path, (sum(listsize)/1024/1024/1024)))

	total_size = sum(listsize)
	return total_size

#定义函数,统计备份文件大小 (一次备份只存在一个文件的情况)
def get_file_size(backup_path):
	total_size = os.path.getsize(backup_path)
	return total_size

#计算当天的备份文件大小
if os.path.isdir(today_backup_path):
	today_backup_size = get_size(today_backup_path)
else:
	today_backup_size = get_file_size(today_backup_path)

print today_backup_size

#计算前一天的备份文件大小
if os.path.isdir(previous_backup_path):
	previous_backup_size = get_size(previous_backup_path)
else:
	previous_backup_size = get_file_size(previous_backup_path)

print previous_backup_size

#检验备份,如果失败，则触发钉钉报警
if today_backup_size >= previous_backup_size:
	print ("备份成功!")
else:
	#error_msg = "测试！！！！备份异常! 今日%s的备份文件大小：%.2f MB, 昨日%s的备份文件大小：%.2f MB" % (today,today_backup_size/1024/1024,yesterday,previous_backup_size/1024/1024)
	error_msg = """
		测试！！！
		备份类型：[完整备份]
		备份服务器名称：%s
		备份状态：[异常]
		今日%s的备份文件大小：%.2f MB
		昨日%s的备份文件大小：%.2f MB
		备份文件大小差异：%.2f MB

		请检查备份数据的完整性
		""" % (hostname,today,today_backup_size/1024/1024,yesterday,previous_backup_size/1024/1024,(previous_backup_size-today_backup_size)/1024/1024)

	text_content = subject_msg + error_msg
	data = get_data(text_content)
	dingding_alert(data)

