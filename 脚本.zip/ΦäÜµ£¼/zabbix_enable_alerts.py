import requests
import json

zabbix_url = "https://zabbix.hkbge.com/api_jsonrpc.php"
token = '2b031ff1a56ebb7cd6ed3a3193b86949'

# 获取主机的触发器
def get_host_triggers(host):
	headers = {'Content-Type': 'application/json-rpc'}
	data = {
		'jsonrpc': '2.0',
		'method': 'trigger.get',
		'params': {
			'host' : host,
			'output': ['triggerid', 'description', 'status']
		},
		'auth': token,
		'id': 2
	}

	response = requests.post(zabbix_url, headers=headers, data=json.dumps(data))
	result = response.json()
	return result['result']

# 关闭主机的所有触发器
def disable_host_triggers(host):
	headers = {'Content-Type': 'application/json-rpc'}
	triggers = get_host_triggers(host)
	for trigger in triggers:
		trigger_id = trigger['triggerid']
		data = {
			'jsonrpc': '2.0',
			'method': 'trigger.update',
			'params': {
				'triggerid': trigger_id,
				'status': 0  # 0表示启用，1表示禁用
				},
			'auth': token,
			'id': 3
			}
		response = requests.post(zabbix_url, headers=headers, data=json.dumps(data))
		result = response.json()
	if 'result' in result:
		print(f"成功开启主机 {host} 的报警")
	else:
		print(f"开启主机 {host} 报警失败：{result['error']['message']}")
	return result['result']
	
host = 'hk-bge-prod-ops-archery-a01'
disable_host_triggers(host)
