#encoding=utf-8
import requests
from datetime import datetime, timedelta
import pymongo
import whois
import json
import ssl
import socket

# 连接到数据库
client = pymongo.MongoClient('mongodb://cmdb:cmdb123456@172.18.132.106:27017/')
db = client['cmdb']
domains = db['model_data']


#定义钉钉报警
def dingding_alert(data):
    headers = {'Content-Type':'application/json;charset=utf-8'}
    webhook = "https://oapi.dingtalk.com/robot/send?access_token=2d4ec3bfee21d6f08097b47316f7dfaf555bdf405561f4996d17aafc668ed5b5"
    #webhook = "https://oapi.dingtalk.com/robot/send?access_token=6fe7bf68c04b7af45a448befd65e2270f9a5c6058f215cdac05cc85d642a50e9"
    requests.post(url=webhook,data=json.dumps(data),headers=headers)

def get_data(text_content):
    text = {
            "msgtype":"text",
            "text":{
                "content":text_content
                },
            }
    return text

#获取域名的过期时间与SSL证书过期时间
def domain_expire_date():
    # 查询域名列表
    for domain in domains.find({"data.domain_alert_name": {"$exists": True}}):
        # 查询域名信息
        domain_info = whois.whois(domain['data']['domain_alert_domain_name'])
        domain_name = domain['data']['domain_alert_domain_name']
        if isinstance(domain_info.expiration_date, list):
            expire_date = domain_info.expiration_date[0]
        else:
            expire_date = domain_info.expiration_date
        # 更新域名的过期时间
        domains.update_one({'_id': domain['_id']}, {'$set': {'data.domain_alert_expire_date' : expire_date}})


        #SSl证书信息获取
        context = ssl.create_default_context()
        with socket.create_connection((domain_name, 443)) as sock:
            with context.wrap_socket(sock, server_hostname=domain_name) as secure_sock:
                # 获取证书信息
                certificate = secure_sock.getpeercert()
        # 提取SSL到期时间
        ssl_expire_date_str = certificate['notAfter']
        ssl_expire_date = datetime.strptime(ssl_expire_date_str, "%b %d %H:%M:%S %Y %Z")
        # 更新SSL证书的到期时间到MongoDB数据库
        domains.update_one({'_id': domain['_id']}, {'$set': {'domain_alert_ssl_expire_date' : ssl_expire_date}})


        if expire_date:
            days_remaining = (expire_date - datetime.now()).days
            if days_remaining < 30:
                content = (f"域名 '{domain_name}' 将在 {days_remaining} 天后过期.")

        if ssl_expire_date:
            ssl_days_remaining = (ssl_expire_date - datetime.now()).days
            if ssl_days_remaining < 30:
                ssl_content = (f"域名 '{domain_name}' SSL证书将在 {ssl_days_remaining} 天后过期.")
        


        # 定义报警文本内容
        message = """
                
            域名到期通知
            %s , %s
            域名：%s
            域名到期时间：%s
            SSL证书到期时间：%s
            """ % (content,ssl_content,domain_name,expire_date,ssl_expire_date)
        
        data = get_data(message)
        dingding_alert(data)


if __name__ == '__main__':
    domain_expire_date()
