#!/usr/bin/python3
import boto3
import json

aws_access_key_id = "AKIAYAD2R6SDNRUJ6AJ7"
aws_secret_access_key = "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"
region_name = "ap-east-1"

def get_s3_bucket_info():
    # 创建 AWS 客户端
    s3_client = boto3.client(
        's3',
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
        region_name=region_name
    )

    # 获取所有 S3 桶的描述
    response = s3_client.list_buckets()
    buckets = response['Buckets']
    
    # 解析并构建输出格式
    data_info = []
    unique_fields = ["S3_name"]

    for bucket in buckets:
        bucket_info = {}

        # 获取 S3 桶的名称
        s3_name = bucket['Name']

        # 获取 S3 桶的创建时间
        s3_create_time = bucket['CreationDate'].isoformat()

        s3_info = {
            "S3_name" : s3_name,
            "S3_VISIBLE_NAME" : s3_name,
            "S3_CREATED_TIME" : s3_create_time
                }

        data_info.append(s3_info)

    output = {
            "data_info": data_info,
            "unique_fields": unique_fields
            }
    
    # 输出为JSON格式
    output_json = json.dumps(output, indent=4)
    print(output_json)

if __name__ == '__main__':
    get_s3_bucket_info()
