#!/bin/bash
#Description: bge mysql数据库安装部署与初始化
#Author:WangJie
#Date:2022-11-03

CUR=$(cd "$(dirname "$0")";pwd)

#安装依赖
#yum  install cmake ncurses-devel gcc  gcc-c++  vim  lsof bzip2 openssl-devel ncurses-compat-libs -y

#关闭firewalld防火墙服务，并且设置开机不要启动
service firewalld stop
systemctl disable firewalld

#下载mysql安装包、解压安装
cd /opt/ && wget https://dev.mysql.com/get/Downloads/MySQL-5.7/mysql-5.7.39-el7-x86_64.tar.gz
tar -zxvf mysql-5.7.39-el7-x86_64.tar.gz
mv mysql-5.7.39-el7-x86_64 /usr/local/mysql

#创建用户用户组
groupadd mysql
useradd -r -g mysql mysql

#创建data目录和logs目录
mkdir -p /data/storage/mysql/data/
mkdir -p /data/storage/mysql/logs
chown -R mysql:mysql /usr/local/mysql
chown -R mysql:mysql /data/storage/mysql/data
chown -R mysql:mysql /data/storage/mysql/logs

#配置my.cnf文件
cat  >/etc/my.cnf  <<EOF
[mysqld]
basedir=/usr/local/mysql
datadir=/data/storage/mysql/data
port = 3306
socket=/tmp/mysql.sock

symbolic-links=0
log-error=/data/storage/mysql/logs/mysqld.log
pid-file=/tmp/mysqld.pid
default-storage-engine=INNODB
log-bin=mysql-bin
binlog-format=ROW
binlog_cache_size=65536
expire_logs_days=2
server_id=1
max_connections=2000
max_connect_errors = 800
max_user_connections = 4000
innodb_flush_log_at_trx_commit = 1
innodb_buffer_pool_size = 1024M
innodb_log_file_size= 200M
back_log        = 2048
innodb_lock_wait_timeout        = 50
lock_wait_timeout =50
query_cache_size =0
thread_cache_size = 64
skip_name_resolve =1
slow_query_log =1
long_query_time=0.5
innodb_file_per_table=1
innodb_log_buffer_size=64M
innodb_flush_method=O_DIRECT
innodb_max_dirty_pages_pct=60
innodb_io_capacity_max=3000
innodb_io_capacity=1000
innodb_read_io_threads=4
innodb_write_io_threads=4
sql_mode        = STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION
log_output      = FILE
sync_binlog = 1
innodb_data_file_path = ibdata1:1024M:autoextend
character-set-server=utf8mb4
log_timestamps=SYSTEM
default-time_zone = '+8:00'

EOF

#初始化mysql数据库
/usr/local/mysql/bin/mysqld --initialize --user=mysql --basedir=/usr/local/mysql --datadir=/data/storage/mysql/data

#启动mysql数据库、创建账号并进行权限分配
#/usr/local/mysql/bin/mysqld_safe --user=mysql &

#开机服务启动设置
cp -a /usr/local/mysql/support-files/mysql.server /etc/init.d/mysql
chkconfig --add mysql

#启动mysq服务、账号权限
service mysql restart
temp_passwd=$(cat /data/storage/mysql/logs/mysqld.log |grep "temporary password"|awk '{print $NF}')
/usr/local/mysql/bin/mysql -uroot  -p$temp_passwd --connect-expired-password -e "set password=password('qhxc@021');grant all privileges on *.* to 'root'@'%' identified by 'qhxc@021'; grant select,update,insert,delete on *.* to 'qhxc'@'%' identified by 'qhxcpre1025';flush privileges;"
sleep 2


#判断mysql是否启动成功
count=`ps -ef|grep mysqld|grep -v grep|grep -v mysqld_exporter|wc -l`
if [[ $count == 2 ]];then
  echo "MySQL服务启动成功！"
fi
