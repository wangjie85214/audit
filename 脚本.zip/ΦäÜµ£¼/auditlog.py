# -*- coding: UTF-8 -*-
import datetime
import logging
import traceback

import simplejson as json
from django.contrib.auth.decorators import permission_required
from django.core.exceptions import PermissionDenied
from django.db import transaction
from django.db.models import Q
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from django.shortcuts import render, get_object_or_404
from django.urls import reverse
from django.utils import timezone

from common.config import SysConfig
from common.utils.const import Const, WorkflowDict
from common.utils.extend_json_encoder import ExtendJSONEncoder
from sql.models import ResourceGroup
from sql.utils.resource_group import user_groups, user_instances
from sql.utils.workflow_audit import Audit
from .models import Instance, auditlog
from django_q.tasks import async_task

from sql.engines import get_engine

logger = logging.getLogger('default')


def audit_log_list(request):
    """
    获取审核列表
    :param request:
    :return:
    """
    statement_type = request.POST.get('statement_type')
    start_date = request.POST.get('start_date')
    end_date = request.POST.get('end_date')
    limit = int(request.POST.get('limit'))
    offset = int(request.POST.get('offset'))
    limit = offset + limit
    search = request.POST.get('search')
    user = request.user

    # 组合筛选项
    filter_dict = dict()

    # 实例
    if statement_type:
        filter_dict['statement_type'] = statement_type
    # 时间
    if start_date and end_date:
        end_date = datetime.datetime.strptime(end_date, '%Y-%m-%d %H:%M:%S') + datetime.timedelta(minutes=10)
        filter_dict['create_time__range'] = (start_date, end_date)

    # 过滤组合筛选项
   # workflow = SqlWorkflow.objects.filter(**filter_dict)
    workflow = auditlog.objects.filter(**filter_dict)

    # 过滤搜索项，模糊检索项包括sql语句、请求的客户端ip
    if search:
        workflow = workflow.filter(Q(source_ip__icontains=search) | Q(operation__icontains=search))

    count = workflow.count()
    workflow_list = workflow.order_by('-timestamp')[offset:limit].values(
        "id", "username", "source_ip", "statement_type" ,"database_name",
        "operation", "timestamp"
        )

    # QuerySet 序列化
    rows = [row for row in workflow_list]
    result = {"total": count, "rows": rows}
    # 返回查询结果
    return HttpResponse(json.dumps(result, cls=ExtendJSONEncoder, bigint_as_string=True),
                        content_type='application/json')


