#!/usr/bin/python3
# encoding=utf8

import boto3

# 配置 AWS 访问密钥和访问密钥 ID
aws_access_key_id = 'AKIAYAD2R6SDDNJ5TLFS'
aws_secret_access_key = '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'
region_name='ap-east-1'

# 创建 RDS 客户端
rds_client = boto3.client('rds', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,region_name=region_name)

# 获取所有 RDS 实例

response = rds_client.describe_db_instances(
            Filters=[
                        {
                            'Name': 'db-instance-id',
                            'Values': ['mysql-bge-test','mysql-apollo-test']
                        }
                    ]
            )

#停止rds实例
for instance in response['DBInstances']:
    instance_id = instance['DBInstanceIdentifier']
    if instance['DBInstanceStatus'] != 'stopped':
        rds_client.stop_db_instance(DBInstanceIdentifier=instance_id)
        print(f"Stopping RDS instance {instance_id}")
    else:
        print(f"RDS instance {instance_id} is already stopped")

