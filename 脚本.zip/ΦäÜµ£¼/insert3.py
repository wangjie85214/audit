import time
import pymysql  # pip3 install PyMySQL
import threading
from time import ctime

row_count = 100000  # 总insert的数据量
threads_count = 16  # 并发线程数

def time_me(fn):
    """
    记录方法执行时间
    :param args:
    :param kwargs:
    :return:
    """

    def _wrapper(*args, **kwargs):
        start = time.time()
        fn(*args, **kwargs)
        seconds = time.time() - start
        print("{func}函数每{count}条数数据写入耗时{sec}秒".format(func='ordinary_insert', count=args[0], sec=seconds))

    return _wrapper

@time_me
def run_insert(count):
    db = pymysql.connect(host="aurora-exchange-api-test.cluster-cshckcbibsdx.ap-east-1.rds.amazonaws.com", port=3306, user="admin", passwd="6OeILca2x0c35ga", db="exchange", charset="utf8")
    cur = db.cursor()
    for i in range(count):
        sql = " INSERT INTO orders_test(order_id, pair_code, user_id, broker_id, clazz, side, entrust_price, amount, deal_amount, quote_amount, deal_quote_amount, cancel_amount, stp_amount, source_info, system_order_type, relation_order_id, sub_status, status, system_type, stp, create_on, update_on) VALUES (%d+1,'ETH_USDT','%d'+1000001,%s,1,'buy',0.000000000000000000,0.010000000000000000,0.010000000000000000,0.010000000000000000,0.010000000000000000,0.010000000000000000,0.010000000000000000,'web',0,%d+100002,0,5,0,0,now(),now() ) " % (i,i,i,i) 
        sql2 = " INSERT INTO exchange.t_order_sequence_test(f_version, f_created_at, f_updated_at, f_type, f_order_id, f_symbol, f_amount, f_price, f_circuit_rate, f_order_count, f_retry, f_user_id, f_stp, f_extra) VALUES (0,1661838627344,1661838627344,4,%d,'ETH_BTC' ,1.000000000000000000,1.000000000000000000,0.0000,0,0,1272320771,1,''  )" % (i)
        try:
            cur.execute(sql)
            cur.execute(sql2)
            db.commit()
        except Exception as e:
            print(e)

    db.close()

local_var = threading.local()

def Clean(args):
    local_var.name = args
    run_insert(int(row_count / threads_count))

threads = []
for i in range(threads_count):
    t = threading.Thread(target=Clean, args=(i,))
    threads.append(t)

print('start:', ctime())
start = time.time()

if __name__ == '__main__':
    for i in threads:
        i.start()
    for i in threads:
        i.join()

seconds = time.time() - start
print('end:', ctime())
print("{func}函数每{count}条数数据写入耗时{sec}秒".format(func='ordinary_insert', count=row_count, sec=seconds))

