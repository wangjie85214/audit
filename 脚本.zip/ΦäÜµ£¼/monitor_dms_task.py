#!/usr/bin/python3
#encoding=utf-8
import boto3
import requests
import json

#定义钉钉报警
def dingding_alert(data):
    headers = {'Content-Type':'application/json;charset=utf-8'}
    webhook = "https://oapi.dingtalk.com/robot/send?access_token=2d4ec3bfee21d6f08097b47316f7dfaf555bdf405561f4996d17aafc668ed5b5"
#    webhook = "https://oapi.dingtalk.com/robot/send?access_token=6fe7bf68c04b7af45a448befd65e2270f9a5c6058f215cdac05cc85d642a50e9"
    requests.post(url=webhook,data=json.dumps(data),headers=headers)

def get_data(text_content):
    text = {
            "msgtype":"text",
            "text":{
                "content":text_content
                },
            }
    return text


# 配置 AWS 访问密钥和访问密钥 ID
aws_access_key_id = 'AKIAYAD2R6SDDNJ5TLFS'
aws_secret_access_key = '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'
region_name = 'ap-east-1'

# 创建DMS客户端
dms_client = boto3.client('dms', aws_access_key_id=aws_access_key_id,
                          aws_secret_access_key=aws_secret_access_key,
                          region_name=region_name)

# 要监控的DMS任务名称列表
task_names = ['order-fulfillment-online', 'match-orders-online', 'bill-online']

# 遍历任务名称列表
for task_name in task_names:
    # 获取任务状态
    response = dms_client.describe_replication_tasks(Filters=[
        {'Name': 'replication-task-id', 'Values': [task_name]}
    ])

    # 解析任务状态
    task_status = response['ReplicationTasks'][0]['Status']

    if task_status != 'running':
        content = (f"BGE线上环境 DMS 任务 {task_name} 同步异常")
        data = get_data(content)
        dingding_alert(data)
