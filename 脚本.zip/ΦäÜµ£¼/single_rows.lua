pathtest = string.match(test, "(.*/)")

if pathtest then
   dofile(pathtest .. "common.lua")
else
   require("common")
end

function thread_init(thread_id)
   set_vars()
end

function event()
   local table_name
   local i
   local c_val
   local k_val
   local pad_val

   table_name = bill

   user_id=math.random(100000,99999999)
   broker_id=10000
   symbol='BTC'
   pair_code='BTC_USD'
   deal_side=2
   type=20
   action=1
   delta=-12.000000000000000000
   before_assets=100000.000000000000000000
   after_assets=99988.000000000000000000
   fee=0.000000000000000000
   af=math.random(1,100)
   c_val = sb_rand_str([[###########]])
   k_val = sb_rand_str([[############]])
   notes=''

   if (db_driver == "pgsql" and oltp_auto_inc) then
      rs = db_query("INSERT INTO " .. table_name .. " (k, c, pad) VALUES " ..
                       string.format("(%d, '%s', '%s')", k_val, c_val, pad_val))
   else
      if (oltp_auto_inc) then
         i = 0
      else
         i = sb_rand_uniq()
         i2 = sb_rand_uniq() + 12345
      end
      rs = db_query("begin")
      rs = db_query("INSERT INTO bill (id, user_id, broker_id, symbol, pair_code, deal_side, type, action, delta, before_assets, after_assets, fee, af, refer_id, refer_id2, notes) VALUES " .. string.format("(%d, %d, %d, '%s', '%s', %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, '%s' )",i,user_id,broker_id,symbol,pair_code,deal_side,20,action,delta,before_assets,after_assets,fee,1,k_val,c_val,notes))
      rs = db_query("select * from user_assets where user_id=77539929 and broker_id=10000 and symbol='BTC' for update")
      rs = db_query("update user_assets set hold=hold+1 where user_id=77539929 and broker_id=10000 and symbol='BTC' ")
      rs = db_query("commit")
   end
end
