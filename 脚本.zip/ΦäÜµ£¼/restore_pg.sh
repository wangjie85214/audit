#!/bin/bash

# 恢复文件的路径
BACKUP_DIR="/opt"

# PostgreSQL容器名称
POSTGRES_CONTAINER_NAME="sonarqube_postgres"

# PostgreSQL数据库访问信息
POSTGRES_DB_HOST="localhost"
POSTGRES_DB_PORT="5432"
POSTGRES_DB_NAME="sonar"
POSTGRES_DB_USER="sonar"

# 恢复的文件名
BACKUP_FILENAME="bgw_sonar_$(date +"%Y%m%d").sql.gz"
BACKUP_FILENAME2="bgw_sonar_$(date +"%Y%m%d").sql"

#从S3上下载备份文件
aws s3 cp s3://bgw-dbbackup-dump/sonar/$BACKUP_FILENAME $BACKUP_DIR

#解压、复制备份文件
cd $BACKUP_DIR
gunzip $BACKUP_FILENAME
docker cp $BACKUP_DIR/$BACKUP_FILENAME2 $POSTGRES_CONTAINER_NAME:$BACKUP_DIR

#进入docker恢复数据
docker exec "$POSTGRES_CONTAINER_NAME" /usr/bin/psql -U "$POSTGRES_DB_USER"  -p "$POSTGRES_DB_PORT" -d "$POSTGRES_DB_NAME" -f "$BACKUP_DIR/$BACKUP_FILENAME2"

rm -rf $BACKUP_FILENAME2
