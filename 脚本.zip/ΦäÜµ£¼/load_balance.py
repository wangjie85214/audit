#!/usr/bin/python3
import boto3
import json

aws_access_key_id = "AKIAYAD2R6SDDNJ5TLFS"
aws_secret_access_key = "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"
region_name = "ap-east-1"


def get_load_balancer_info():
    # 创建 AWS 客户端
    elbv2_client = boto3.client(
        'elbv2',
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
        region_name=region_name
    )  # 负载均衡v2版本

    ec2_client = boto3.client(
        'ec2',
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
        region_name=region_name
    )  # EC2 客户端

    # 获取所有负载均衡的描述
    response = elbv2_client.describe_load_balancers()

    # 处理响应结果
    data_info = []
    unique_fields = ["lb_lb_name"]

    for load_balancer in response['LoadBalancers']:
        lb_info = {}

        # 获取负载均衡的名称
        lb_info["lb_lb_name"] = load_balancer['LoadBalancerName']

        # 获取负载均衡的DNS名称
        lb_info["lb_dns_name"] = load_balancer['DNSName']

        # 获取负载均衡的状态
        state = load_balancer['State']
        lb_info["lb_status"] = state['Code']

        # 获取负载均衡的类型
        lb_info["lb_type"] = load_balancer['Type']

        # 获取负载均衡的方案
        lb_info["lb_schema"] = load_balancer['Scheme']

        # 获取负载均衡的VPC
        lb_info["lb_vpc"] = load_balancer['VpcId']

        #获取负载均衡的安全组

        if 'SecurityGroups' in load_balancer:
            security_group_ids = load_balancer['SecurityGroups']
            security_group_names = []

            # 获取安全组名称
            response = ec2_client.describe_security_groups(GroupIds=security_group_ids)
            for group in response['SecurityGroups']:
                security_group_names.append(group['GroupName'])

            lb_info["lb_security_groups"] = security_group_names
        else:
            lb_info["lb_security_groups"] = ""


        # 获取负载均衡的目标组
        target_groups_response = elbv2_client.describe_target_groups(
            LoadBalancerArn=load_balancer['LoadBalancerArn']
        )
        target_groups = target_groups_response['TargetGroups']
        lb_info["lb_target_groups"] = []
        for target_group in target_groups:
            lb_info["lb_target_groups"].append(target_group['TargetGroupName'])

        # 获取负载均衡监听器的信息
        listeners_response = elbv2_client.describe_listeners(LoadBalancerArn=load_balancer['LoadBalancerArn'])
        listeners = listeners_response['Listeners']

        lb_info["lb_listeners"] = []

        for listener in listeners:
            listener_info = {}
            listener_info["协议"] = listener['Protocol']
            listener_info["端口"] = listener['Port']

            if 'DefaultActions' in listener and listener['DefaultActions']:
                default_action = listener['DefaultActions'][0]
                if 'TargetGroupArn' in default_action:
                    listener_info["目标组arn"] = default_action['TargetGroupArn']
                else:
                    listener_info["目标组arn"] = "没有默认的目标组ARN"
            else:
                listener_info["lb_targetgroup_arn"] = "没有默认的动作"

            lb_info["lb_listeners"].append(listener_info)



        data_info.append(lb_info)

    result = {
        "data_info": data_info,
        "unique_fields": unique_fields
    }

    print(json.dumps(result, indent=4, ensure_ascii=False))

if __name__ == '__main__':
    get_load_balancer_info()
