import boto3

aws_access_key_id = 'AKIAYAD2R6SDDNJ5TLFS'
aws_secret_access_key = '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'
region_name='ap-east-1'

# 创建 AWS DMS 客户端
client = boto3.client('dms',aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,region_name=region_name)

# 设置变量
#replication_task_arn = ['arn:aws:dms:ap-east-1:550012843142:task:bill','arn:aws:dms:ap-east-1:550012843142:task:match-orders','arn:aws:dms:ap-east-1:550012843142:task:order-fulfillment']
replication_task_arn = ['arn:aws:dms:ap-east-1:550012843142:task:order-fulfillment-backup','arn:aws:dms:ap-east-1:550012843142:task:bill-backup']

# 启动迁移任务
#response = client.start_replication_task(ReplicationTaskArn=replication_task_arn,StartReplicationTaskType='reload-target')

for task_arn in replication_task_arn:
    response = client.start_replication_task(ReplicationTaskArn=task_arn,StartReplicationTaskType='reload-target')
    message = task_arn + " 数据迁移任务已启动"
    print(message)
