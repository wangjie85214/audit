#!/bin/bash

# 备份文件的保存路径
BACKUP_DIR="/opt"

# PostgreSQL容器名称
POSTGRES_CONTAINER_NAME="sonarqube_postgres"

# PostgreSQL数据库访问信息
POSTGRES_DB_HOST="localhost"
POSTGRES_DB_PORT="5432"
POSTGRES_DB_NAME="sonar"
POSTGRES_DB_USER="sonar"
POSTGRES_DB_PASSWORD="6uPu5L2AvJFoek7AMS"

# 备份文件名
BACKUP_FILENAME="bgw_sonar_$(date +"%Y%m%d").sql.gz"

# 进入PostgreSQL容器并执行备份命令
docker exec "$POSTGRES_CONTAINER_NAME" /usr/bin/pg_dump -U "$POSTGRES_DB_USER"  -p "$POSTGRES_DB_PORT" "$POSTGRES_DB_NAME" -c | gzip > "$BACKUP_DIR/$BACKUP_FILENAME"

cd $BACKUP_DIR
aws s3api put-object --bucket bgw-dbbackup-dump --key sonar/$BACKUP_FILENAME --server-side-encryption AES256 --body "$BACKUP_DIR/$BACKUP_FILENAME"
