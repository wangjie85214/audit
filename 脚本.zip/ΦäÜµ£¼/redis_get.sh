#!/bin/bash
for((i=1;i<50000;i++))
do
/usr/local/redis/src/redis-cli -p 6379 get k$i
done
