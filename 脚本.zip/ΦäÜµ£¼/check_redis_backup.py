#!/usr/bin/python
#encoding=utf-8
#Description: 对备份文件进行备份检验、失败触发报警
#Author: WangJie
#Date: 2023-05-12
#Remark：使用Python3环境，机器需要安装boto3库（pip3 install boto3）
#Comment: 只需要修改bucket_name、dir_path、today_str、yesterday_str 、subject_msg 这五个变量的值即可。
 
import boto3
import os,requests,json,sys
from datetime import datetime,timedelta
import re
import socket
 
# 创建 S3 客户端
s3 = boto3.client('s3', aws_access_key_id='AKIAYAD2R6SDDNJ5TLFS',aws_secret_access_key='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')
 
#修改以下三个变量的值,修改为自己设置的备份目录或备份文件名称
 
# 备份在S3 的bucket
bucket_name = 'qhxc-dbbackup-dump'
 
# 备份在S3 的bucket下的目录
dir_path = 'redis/'
 
# 匹配日期为今天的备份文件,假设备份文件中的日期格式为yyyymmdd.
today_str = datetime.now().strftime('%Y%m%d')
 
# 匹配日期为昨天的备份文件
yesterday_str = (datetime.now() - timedelta(days=1)).strftime('%Y%m%d')
 
# 钉钉报警的主题描述内容
subject_msg = "Redis备份  "
 
#获取主机名信息
hostname = socket.gethostname()
 
 
#钉钉报警
def dingding_alert(content, at_users=[]):
 
    #把消息提交给钉钉机器人
    headers = {'Content-Type':'application/json;charset=utf-8'}
#    webhook = "https://oapi.dingtalk.com/robot/send?access_token=2d4ec3bfee21d6f08097b47316f7dfaf555bdf405561f4996d17aafc668ed5b5"
    webhook = "https://oapi.dingtalk.com/robot/send?access_token=6fe7bf68c04b7af45a448befd65e2270f9a5c6058f215cdac05cc85d642a50e9"

    data = {
        "msgtype": "text",
        "text": {
            "content": content
        },
        "at": {
            "atMobiles": at_users
        }
    }

    response = requests.post(url=webhook, data=json.dumps(data), headers=headers)

 
 
#定义函数
def get_file_total_size(date_str):
    # 初始化文件大小
    total_size = 0
     
    # 使用Boto3分页器Paginator列出S3,并统计所有文件大小
 
    paginator = s3.get_paginator('list_objects_v2')
    page_iterator = paginator.paginate(Bucket=bucket_name, Prefix=dir_path)
    for page in page_iterator:
        if 'Contents' in page:
            for obj in page['Contents']:
                if date_str in obj['Key']:
                    obj_size = obj['Size']
                    total_size += obj_size
    return total_size
 
 
#计算当天的备份文件大小
today_total_file_size=get_file_total_size(today_str)
print (today_total_file_size)
 
#计算昨天的备份文件大小
yesterday_total_file_size = get_file_total_size(yesterday_str)
print (yesterday_total_file_size)
 
#检验备份,如果当日备份小于昨日的备份文件大小，则触发钉钉报警
if today_total_file_size >= yesterday_total_file_size and today_total_file_size > 0:
        print ("备份成功!")
        message = """
            备份类型：全量备份
            备份服务器名称：%s
            备份状态：备份成功
            备份文件大小：%.4f MB
            """ % (hostname,today_total_file_size/1024/1024)

        text_content = subject_msg + message
        dingding_alert(text_content)
        
else:
    error_msg = """
        备份类型：[完整备份]
        备份服务器名称：%s
        备份状态：[异常]
        今日%s的备份文件大小：%.4f MB
        昨日%s的备份文件大小：%.4f MB
        备份文件大小差异：%.2f MB
 
        请检查备份数据的完整性
        """ % (hostname,today_str,today_total_file_size/1024/1024,yesterday_str,yesterday_total_file_size/1024/1024,(yesterday_total_file_size-today_total_file_size)/1024/1024)

    at_users = ["13220187293"]
    text_content = subject_msg + error_msg
    dingding_alert(text_content,at_users)

