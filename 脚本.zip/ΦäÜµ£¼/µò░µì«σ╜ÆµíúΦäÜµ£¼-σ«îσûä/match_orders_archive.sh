#!/bin/bash

# 定义数据库连接信息
YEAR_MONTH=$(date +'%Y_%m')
user="qhxc"
password="qhxcpre1025"
host="192.168.13.139"
database="exchange"
table="match_orders"
#archive_table=$table_$(date +%Y_%m)
archive_table="${table}_${YEAR_MONTH}"
echo $archive_table

# 计算当前时间前3天的时间戳
three_days_ago=$(date -d "1 days ago" +%s)

# 查询表数据数量和最早时间戳
query="SELECT COUNT(*), MIN(create_time) FROM $table"
result=$(mysql -u$user -p$password -h$host $database -e "$query" |sed -n '2,1p')
count=$(echo $result | awk '{print $1}')
oldest_timestamp=$(echo $result | awk '{print $2}')
oldest_timestamp=`date -d "$oldest_timestamp" +%s`
echo $oldest_timestamp

# 判断是否需要进行归档
if [[ $count -gt 20000000 ]] || [[ $oldest_timestamp -lt $three_days_ago ]]; then

  # 归档数据
  pt-archiver \
    --source h=$host,D=$database,t=$table,u=$user,p=$password \
    --purge \
    --where "id <= (SELECT MAX(id) FROM $table) - 200 or (create_time < DATE_SUB(NOW(), INTERVAL 3 DAY)) " \
    --limit 10000 \
    --txn-size 1000 \
    --statistics \
    --ignore \
    --progress 10000 \
    --no-check-charset

fi
