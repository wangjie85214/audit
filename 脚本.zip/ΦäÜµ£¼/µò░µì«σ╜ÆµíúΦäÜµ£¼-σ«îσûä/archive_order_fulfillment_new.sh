#!/bin/bash

# 定义数据库连接信息
YEAR_MONTH=$(date +'%Y_%m')
user="root"
password="qhxc@021"
host="192.168.13.139"
database="exchange"
table="order_fulfillment"
archive_table="${table}_${YEAR_MONTH}"

# 计算当前时间前3天的时间戳
three_days_ago=$(date -d "3 days ago" +%s)

# 查询表数据数量和最早时间戳
query="SELECT COUNT(*), MIN(create_on) FROM $table"
result=$(mysql -u$user -p$password -h$host $database -e "$query" |sed -n '2,1p')
count=$(echo $result | awk '{print $1}')
oldest_timestamp=$(echo $result | awk '{print $2}')
oldest_timestamp=`date -d "$oldest_timestamp" +%s`

# 判断是否需要进行归档
if [[ $count -gt 20000000 ]] || [[ $oldest_timestamp -lt $three_days_ago ]]; then

  # 归档数据
  pt-archiver \
    --source h=$host,D=$database,t=$table,u=$user,p=$password \
    --dest h=$host,D=$database,t=$archive_table,u=$user,p=$password \
    --where "create_on < DATE_SUB(NOW(), INTERVAL 3 DAY)" \
    --limit 10000 \
    --txn-size 1000 \
    --bulk-delete \
    --bulk-insert \
    --statistics \
    --ignore \
    --progress 10000 \
    --no-check-charset

fi

#写入归档日志
end_id=$(mysql -u$user -p$password -h$host $database -e "select max(id) as end_id from $archive_table " |sed -n '2,1p')
mysql -u$user -p$password -h$host $database -e "insert into archive_logs(table_name,begin_id,end_id) select '$archive_table',min(id) as begin_id,max(id) as end_id from $archive_table on duplicate key update end_id=${end_id};"

