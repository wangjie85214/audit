#!/bin/bash

# 定义数据库连接信息
YEAR_MONTH=$(date +'%Y_%m')
user="qhxc"
password="qhxcpre1025"
host="192.168.13.139"
database="exchange"
table="t_order_sequence"
archive_table="${table}_${YEAR_MONTH}"

# 计算当前时间前3天的时间戳
three_days_ago=$(date -d "1 days ago" +%s)
#计算当前时间前15天的unix时间时间戳
time=`date +%s`
last_15_days=$(((${time}+3600*8)/86400*86400-3600*320))'000'

# 查询表数据数量和最早时间戳
query="SELECT COUNT(*), MIN(f_created_at) FROM $table"
result=$(mysql -u$user -p$password -h$host $database -e "$query" |sed -n '2,1p')
count=$(echo $result | awk '{print $1}')
oldest_timestamp=$(echo $result | awk '{print $2}')

# 判断是否需要进行归档
if [[ $count -gt 20000000 ]] || [[ $oldest_timestamp -lt $last_15_days ]]; then

  # 归档数据
  pt-archiver \
    --source h=$host,D=$database,t=$table,u=$user,p=$password \
    --purge \
    --where "f_id <= (SELECT MAX(f_id) FROM $table) - 200 or (f_created_at < $last_15_days)" \
    --limit 10000 \
    --txn-size 1000 \
    --statistics \
    --ignore \
    --progress 10000 \
    --no-check-charset

fi
