#!/bin/bash
#Description: 按照环境创建es索引
#Author:WangJie
#Date:2023-02-21

source /etc/profile
CUR=$(cd "$(dirname "$0")";pwd)

time=`date +%s`

es_user=elastic
es_passwd=2STTKpSTtSeR
es_host='192.168.10.127:9200'


dst_env=$(grep xxenvxx $CUR/Configuration|awk -F= '{print $2}')

order_fulfillment=order_fulfillment_$dst_env
match_orders=match_orders_$dst_env
bill=bill_$dst_env

#创建索引

curl -XPUT "http://$es_user:$es_passwd@$es_host/$order_fulfillment" -H 'Content-Type: application/json' -d'{  "settings": {    "index": {      "sort.field":"id",        "sort.order": "desc"    },      "number_of_shards" : 3  },  "mappings": {    "properties": {     "nid": {        "type": "long"      },      "id": {        "type": "long"      },      "order_id": {        "type": "long"      },      "pair_code": {        "type": "keyword"      },      "user_id":{        "type":"long"      },      "broker_id": {        "type":"integer"      },      "clazz": {        "type":"integer"      },      "side": {        "type":"keyword"      },      "entrust_price": {        "type":"keyword"      },      "amount":{        "type":"keyword"      },      "deal_amount": {        "type":"keyword"      },      "quote_amount":{        "type":"keyword"      },      "deal_quote_amount":{        "type":"keyword"      },      "cancel_amount":{        "type":"keyword"      },      "stp_amount":{        "type":"keyword"      },      "source_info":{        "type":"keyword"      },      "system_order_type":{        "type":"integer"      },      "relation_order_id":{        "type":"keyword"      },      "sub_status":{        "type":"integer"      },      "status":{        "type":"integer"      },      "system_type":{        "type":"integer"      },      "stp":{        "type":"integer"      },      "create_on":{        "type":"date",        "format": "yyyy-MM-dd HH:mm:ss.SSS||yyyy-MM-dd HH:mm:ss.SS||yyyy-MM-dd HH:mm:ss||yyyy-MM-dd HH:mm:ss.S||epoch_millis"      },      "update_on":{        "type":"date",        "format": "yyyy-MM-dd HH:mm:ss.SSS||yyyy-MM-dd HH:mm:ss.SS||yyyy-MM-dd HH:mm:ss||yyyy-MM-dd HH:mm:ss.S||epoch_millis"      }    }  }  }'


curl -XPUT "http://$es_user:$es_passwd@$es_host/$bill" -H 'Content-Type: application/json' -d'{   "settings": {    "index": {      "sort.field":"id",        "sort.order": "desc"    },    "number_of_shards" : 3  },  "mappings": {    "properties": {      "id": {        "type": "long"      },      "user_id": {        "type":"long"      },      "broker_id":{        "type":"integer"      },      "symbol": {        "type": "keyword"      },      "pair_code": {        "type":"keyword"      },      "deal_side":{        "type":"integer"      },      "type": {        "type":"integer"      },      "action": {        "type":"integer"      },      "delta":{        "type":"keyword"      },      "before_assets":{        "type":"keyword"      },      "after_assets":{        "type":"keyword"      },      "fee":{        "type":"keyword"      },      "af": {        "type":"integer"      },      "refer_id": {        "type": "keyword"      },      "refer_id2":{        "type":"keyword"      },               "notes":{        "type":"keyword"      },      "create_on":{        "type":"date",        "format": "yyyy-MM-dd HH:mm:ss.SSS||yyyy-MM-dd HH:mm:ss.SS||yyyy-MM-dd HH:mm:ss||yyyy-MM-dd HH:mm:ss.S||epoch_millis"      },      "update_on":{        "type":"date",        "format": "yyyy-MM-dd HH:mm:ss.SSS||yyyy-MM-dd HH:mm:ss.SS||yyyy-MM-dd HH:mm:ss||yyyy-MM-dd HH:mm:ss.S||epoch_millis"      }    }  }}'

curl -XPUT "http://$es_user:$es_passwd@$es_host/$match_orders" -H 'Content-Type: application/json' -d'{  "settings": {    "index": {      "sort.field":"id",        "sort.order": "desc"    },    "number_of_shards" : 3       },  "mappings": {        "properties": {      "id": {        "type": "long"              },      "order_id": {        "type": "long"      },      "oppo_order_id": {        "type": "long"      },      "user_id":{        "type":"long"      },      "broker_id": {        "type":"integer"      },      "pair_code": {        "type": "keyword"              },      "mr_id": {        "type":"long"      },            "clazz": {        "type":"integer"      },      "system_type": {        "type":"integer"      },      "side": {        "type":"integer"      },      "deal_side": {        "type":"integer"      },      "entrust_price": {        "type":"keyword"      },      "filled_amount":{        "type":"keyword"      },      "price": {        "type":"keyword"      },      "unfilled_amount":{        "type":"keyword"      },      "deal_status":{        "type":"integer"      },      "order_status":{        "type":"integer"      },      "bill_status":{        "type":"integer"      },      "ext":{        "type":"keyword"      },            "create_time":{        "type":"date",        "format": "yyyy-MM-dd HH:mm:ss.SSS||yyyy-MM-dd HH:mm:ss.SS||yyyy-MM-dd HH:mm:ss||yyyy-MM-dd HH:mm:ss.S||epoch_millis"      },      "update_time":{        "type":"date",        "format": "yyyy-MM-dd HH:mm:ss.SSS||yyyy-MM-dd HH:mm:ss.SS||yyyy-MM-dd HH:mm:ss||yyyy-MM-dd HH:mm:ss.S||epoch_millis"      }    }      }  }'



