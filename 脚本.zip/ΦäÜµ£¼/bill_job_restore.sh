#!/bin/bash
#description: flink job restore script
#Author: WangJie
#Date: 2022-11-22

job_basepath='/data/storage/flink/checkpoints/bill'
jobid=`ls -lSt $job_basepath |sed -n '2,1p'|awk -F ' ' '{print $9}'`
job_chk=`ls -lSt $job_basepath/$jobid |sed -n '2,1p'|awk -F ' ' '{print $9}' ` 
job_restore_path=$job_basepath/$jobid/$job_chk

sed -i '/execution.savepoint.path/d' bill_job.sql 

sed -i "1i set 'execution.savepoint.path' = '$job_restore_path' " bill_job.sql 

/data/flink/bin/sql-client.sh -f bill_job.sql
